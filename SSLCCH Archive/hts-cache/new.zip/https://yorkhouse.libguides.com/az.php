<!DOCTYPE html>
<html lang="en">
<head>
    <title>A-Z Databases</title>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge"/>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <script>
        var is_bootstrap = 0;
    </script>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="robots" content="noarchive"/>
    <link rel="canonical" href="https://yorkhouse.libguides.com/az.php"/>
<!-- favicon.twig -->
<link rel="apple-touch-icon" sizes="180x180" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/favicon-16x16.png">
<link rel="manifest" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/site.webmanifest">
<link rel="mask-icon" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/safari-pinned-tab.svg" color="#5bbad5">
<link rel="shortcut icon" href="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/favicon.ico">
<meta name="msapplication-TileColor" content="#ffc40d">
<meta name="msapplication-config" content="//d1qywhc7l90rsa.cloudfront.net/apps/common/favicon/browserconfig.xml">
<meta name="theme-color" content="#ffffff">
<!-- !favicon.twig -->


<link rel="stylesheet" href="https://static-assets-ca.libguides.com/web/jquery/css/jquery-ui.min.css?2691"/>

<link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>

    <link rel="stylesheet" href="https://static-assets-ca.libguides.com/web/css3.22.1/lg-public-no-bs.min.css"/>

    <script type="text/javascript" src="https://static-assets-ca.libguides.com/web/jquery/js/1.12.4_jquery.min.js"></script>

<!-- js_include_fallback_lg.twig -->
<script src="//code.jquery.com/ui/1.13.2/jquery-ui.min.js"></script>
<script>jQuery.ui || document.write('<script src="https://static-assets-ca.libguides.com/web/jquery/js/jquery-ui.min.js?2691">\x3C/script>');</script>
<!-- !js_include_fallback_lg.twig -->

    <script type="text/javascript" src="https://static-assets-ca.libguides.com/web/js3.22.1/lg-public-no-bs.min.js"></script>

    <script src="https://static-assets-ca.libguides.com/web/select2-3.5.2/select2.js"></script>
    <link rel="stylesheet" href="https://static-assets-ca.libguides.com/web/select2-3.5.2/select2.css"/>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"
  integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link
  href="https://fonts.googleapis.com/css2?family=IBM+Plex+Serif:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;1,100;1,200;1,300;1,400;1,500;1,600;1,700&family=Libre+Caslon+Display&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap"
  rel="stylesheet">

<style>
  /* Define palette & fonts */
  :root {
    --bs-body-font-family: "IBM Plex Serif", sans-serif;
    --bs-body-font-weight: 300;
    --header-font-family: "Montserrat", sans-serif;
    --brand-white: white;
    --brand-black: black;
    --brand-yellow: rgba(243, 189, 71, 1);
    --brand-green: rgba(0, 83, 46, 1);
    --brand-green-faded: rgba(0, 83, 46, 0.5);
    --brand-pink: rgba(242, 122, 210, 1);
  }

  /* Site-wide Styling */
  body {
    padding: 0;
    overflow-x: hidden;


    /* Apply header fonts */
    & h1,
    & h2,
    & h3,
    & h4,
    & h5,
    & h6,
    & .nav-link,
    & #navbar-home-link {
      font-family: var(--header-font-family);
    }


    /* Include default LibGuide .hide class */
    & .hide {
      display: none;
    }

    /* Include default LibGuide .btn-group class */
    & #s-lg-az-index>.btn-group {
      flex-wrap: wrap;
    }

    & .navbar-brand,
    & .navbar-collapse {
      padding: 0;

    }

    /* Remove the blue outline around clicked items. */
    & a:focus {
      outline: none;
    }

    /* Scale down profile image - Phillip's request */
    & .s-lib-profile-image>img {
      width: 25%;
    }

    /* Restyle profile email buttons */
    & .s-lib-profile-email .label-info {
      color: var(--brand-green);
      background-color: transparent !important;

      &:hover,
      &:active,
      &:focus {
        color: var(--brand-pink);
      }
    }

    /* Style multicolour img/svg buttons using sepia to force all to a single hue. */
    & .logo-link {
      & .cls-1 {
        fill: white;
      }

      & .cls-2 {
        fill: var(--brand-yellow);
      }

      &:active,
      &:focus,
      &:hover {

        & img,
        & svg {
          filter: contrast(0.8) brightness(.7) sepia(1) hue-rotate(230deg) saturate(8);
        }
      }
    }

    & input,
    & textarea {
      &:not(:focus):hover {
        color: var(--brand-pink) !important;

        &::placeholder {
          color: var(--brand-pink) !important;
        }
      }
    }


    /* Site Header Styling */
    & #site-header {
      position: fixed;
      width: 100%;
      top: 0;
      z-index: 5;
      background-color: var(--brand-green);
      padding: 8px;

      & #navbar-home-link,
      & #navbar-search {
        min-width: 130px;
        max-width: 200px;
      }

      & #navbar-home-link {
        /* Style Brand Text */
        font-size: .7rem;
        line-height: .7rem;
        font-weight: 400;
        text-transform: uppercase;
        text-decoration: none;
        display: flex;
        align-items: center;
        gap: 16px;

        & svg {
          height: 56px;
        }
      }

      & #navbar-search input {
        margin: 0;
      }
      & .navbar-toggler-icon {
        background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%28255, 255, 255, 1%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e")
      }

      & .dropdown-menu {
        background-color: var(--brand-green);
      }

    }

    & .site-nav {

      & a,
      & span {
        color: white;
        text-decoration: none;
        text-transform: uppercase;

        &:active,
        &:focus,
        &:hover {
          color: var(--brand-pink);
          background-color: var(--brand-green);
          text-shadow: 1px 0 0 var(--brand-pink);
        }
      }

      & input {
        color: var(--brand-green);

        &::placeholder {
          color: var(--brand-green-faded);
        }
      }

      .dropdown-divider {
        border-top: 1px solid white;
      }
    }


    /* offset main content by the fixed position header's width */
    & .page-content {
      padding-top: 72px;
    }

    /* Make Cookies modal more visible - Phillip's Request */
    #s-ui-cc-navbar {
      background: var(--brand-pink);
      height: 25%;
      top: 33%;
      z-index: 100;

      & #s-ui-cc-msg-container {
        margin: auto;
      }
    }

    & .carousel-card {
      display: flex;
      flex-direction: column;
      flex: 0 0 auto;
      padding: 8px;
      border: 1px solid var(--brand-green-faded);
      border-radius: 8px;
      color: var(--brand-green);
      box-shadow: 0px 2px 2px var(--brand-green-faded);

      & .carousel-card-image {
        max-width: 100%;
        max-height: 100%;
        object-fit: cover;
      }

      & .carousel-card-title {
        font-size: 16px;
        font-weight: 500;
        color: var(--brand-black);
        line-height: 140%;
        padding: 8px 0px;
        font-family: var(--bs-body-font-family);

        & a {
          font-size: 16px;
          font-weight: 500;
          color: black;
          text-decoration-color: rgba(0, 0, 0, .33);
          padding: 1px 0;
          /* Ensure there is no whitespace between wrapped lines */

          &:hover {
            color: var(--brand-pink);
          }
        }
      }

      /*Metadata*/
      & .pad-bottom-sm {
        margin-top: auto;

        /*Subject Link*/
        & .clearfix div a {
          color: var(--brand-green);
          border-radius: 8px;
          margin: 1px;
          padding: 0 6px;
          display: inline-block;
          outline: solid 1px var(--brand-green-faded);
          outline-offset: -1px;
          text-decoration: none;

          &:hover {
            color: var(--brand-white);
            background: var(--brand-pink);
          }
        }

        /*Views Label*/
        & .pad-left-med:after {
          content: "view(s)";
        }

        /*Hide Author, Default Link, Tags & Close Button*/
        /* Author */
        &>div>div:nth-of-type(2),
        /* Date & Views */
        &>.clearfix:nth-of-type(1),
        /* Tags */
        &>.clearfix:nth-of-type(2),
        /* Labels for "Subjects:" and "Tags:" */
        &>.clearfix span,
        /* "Go to Guide" default button */
        &>div:has(button) {
          display: none;
        }

      }
    }

    & #site-footer {
      background: var(--brand-green);
      color: white;
      margin-top: 128px;

      & #general-info,
      & .site-nav {
        display: flex;
        width: 100%;
        justify-content: space-around;
        flex-wrap: wrap;

        &>* {
          font-family: var(--header-font-family);
          padding: 16px;
        }
      }

      & #general-info>* {
        min-width: 400px;
        flex: 1 0 33%;
        min-height: 250px;
        display: flex;
        flex-direction: column;

        & h2 {
          text-align: center;
        }
      }

      & #hours-and-map>div {
        display: flex;
        white-space: nowrap;
        justify-content: space-between;
        gap: 8px;

        & img {
          object-fit: cover;
          width: 50%;
          object-position: 0% 20%;
        }

        & th {
          text-align: right;
          padding-right: .75em;
        }
      }

      & #external-links {
        gap: 8px;

        &>* {
          flex-grow: 1;
        }

        & .logo-link {
          display: flex;

          & svg {
            margin: auto auto 0 auto;
            height: 64px;
          }
        }

        & .external-media-icon:hover svg {
          fill: var(--brand-pink);
        }

        &>nav {
          display: flex;
          justify-content: center;
          gap: 8px
        }
      }

      & #help-form {
        &>* {
          width: 100%;
        }

        input[type="email"],
        textarea {
          color: var(--brand-green-faded);
        }

        & div {
          display: flex;

          & textarea {
            flex: 1;
            min-height: 100px;
            height: 100px;
          }
        }

        & button {
          border: none;
          border-radius: 0 4px 4px 0;
          text-transform: uppercase;
          color: var(--brand-green);
          background-color: var(--brand-yellow);
          width: 100px;
          height: 100px;

          &:hover {
            color: white;
            background-color: var(--brand-pink);
          }

          &:focus:after {
            content: "✓";
            font-size: xx-large;
          }

          &:not(:focus):after {
            content: "Submit";
          }

        }

        &:has(:focus) {

          & input:not(:placeholder-shown),
          & textarea:not(:placeholder-shown) {
            &:invalid {
              background-color: #ffdddd;
            }

            &:valid {
              background-color: #ddffdd;
            }
          }

          & form {
            & :invalid {
              border: 5px solid #ffdddd;
            }

            & :valid {
              border: 5px solid #ddffdd;
            }
          }
        }
      }

      & .site-nav dt {
        padding: 32px 0;
      }

      & #default-disclaimer {
        display: block;
        text-align: center;
      }
    }

    #default-footer,
    #s-lib-footer-login-link {
      display: none;
    }
  }

  /* Responsive Site Header */
  @media (min-width: 961px) {
    #site-header {
      & #collapsing-navigation {
        display: flex !important;
        flex-basis: auto;
      }

      & .navbar-toggler {
        display: none;
      }

      .navbar-nav .nav-link {
        padding-right: var(--bs-navbar-nav-link-padding-x);
        padding-left: var(--bs-navbar-nav-link-padding-x);
      }

      .navbar-nav .dropdown-menu {
        position: absolute;
      }

      & .dropdown:hover .dropdown-menu {
        display: block;
        margin-top: 0;
      }

      & .navbar-nav {
        flex-direction: row;
        margin: auto;
        margin-right: auto;
        margin-bottom: auto;
      }
    }
  }

  /* Default LibGuide Pagination for Search Page */
  #search .pagination {
    display: inline-block;
    padding-left: 0;
    margin: 20px 0;
    border-radius: 4px;

    &>li {
      display: inline
    }

    &>li>a,
    &>li>span {
      position: relative;
      float: left;
      padding: 6px 12px;
      margin-left: -1px;
      line-height: 1.42857143;
      color: #337ab7;
      text-decoration: none;
      background-color: #fff;
      border: 1px solid #ddd
    }

    &>li>a:hover,
    &>li>span:hover,
    &>li>a:focus,
    &>li>span:focus {
      z-index: 2;
      color: #23527c;
      background-color: #eee;
      border-color: #ddd
    }

    &>li:first-child>a,
    &>li:first-child>span {
      margin-left: 0;
      border-top-left-radius: 4px;
      border-bottom-left-radius: 4px
    }

    &>li:last-child>a,
    &>li:last-child>span {
      border-top-right-radius: 4px;
      border-bottom-right-radius: 4px
    }

    &>.active>a,
    &>.active>span,
    &>.active>a:hover,
    &>.active>span:hover,
    &>.active>a:focus,
    &>.active>span:focus {
      z-index: 3;
      color: #fff;
      cursor: default;
      background-color: #337ab7;
      border-color: #337ab7
    }

    &>.disabled>span,
    &>.disabled>span:hover,
    &>.disabled>span:focus,
    &>.disabled>a,
    &>.disabled>a:hover,
    &>.disabled>a:focus {
      color: #777;
      cursor: not-allowed;
      background-color: #fff;
      border-color: #ddd
    }

    &.pagination-lg {

      &>li>a,
      &>li>span {
        padding: 10px 16px;
        font-size: 18px;
        line-height: 1.3333333
      }

      &>li:first-child>a,
      &>li:first-child>span {
        border-top-left-radius: 6px;
        border-bottom-left-radius: 6px
      }

      &>li:last-child>a,
      &>li:last-child>span {
        border-top-right-radius: 6px;
        border-bottom-right-radius: 6px
      }
    }

    &.pagination-sm {

      &>li>a,
      &>li>span {
        padding: 5px 10px;
        font-size: 12px;
        line-height: 1.5
      }

      &>li:first-child>a,
      &>li:first-child>span {
        border-top-left-radius: 3px;
        border-bottom-left-radius: 3px
      }

      &>li:last-child>a,
      &>li:last-child>span {
        border-top-right-radius: 3px;
        border-bottom-right-radius: 3px
      }
    }
  }

  /* Home Page Styling */
  #homepage {
    & #homepage-hero {
      display: flex;
      flex-direction: row;
      justify-content: flex-start;
      align-items: flex-start;
      width: 100%;
      height: 150px;
      flex-wrap: wrap;
      overflow: hidden;

      & .title-container {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        flex: 1 0 1%;
        width: fit-content;
        height: 100%;
        background: var(--brand-green);
      }

      & .title-bookends:nth-of-type(2) {
        margin-left: -64px;
      }

      & .title-bookends:nth-of-type(1) {
        transform: scaleX(-1);
        margin-right: -64px;
      }

      & .title-text {
        height: 100%;
        padding: 16px;
        margin: auto;

        & h1,
        & h2 {
          color: var(--brand-white);
          text-shadow: 0px 0px 4px #000;
          white-space: nowrap;
          width: 100%;
          text-align: center;
          margin: 0;
        }

        & h1 {
          font-weight: 400;
          font-size: min(24px, 5.75vw);
          height: 28.8px;
          /* Keep spacing even if text is empty. */
        }

        & h2 {
          font-weight: 300;
          font-size: min(52px, 12.75vw);
        }
      }

      & .hero-image {
        flex: 1 1 33%;
        min-width: 33%;
        height: 100%;
        object-fit: cover;
      }
    }

    & .feature-section {
      padding: 32px 0;
      max-width: 1200px;
      margin: auto;

      & .feature-section-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;

        &>* {
          flex: 1 0 auto;
        }

        & p {
          min-width: 260px;
          color: var(--brand-green);
          text-transform: uppercase;
          font-family: var(--header-font-family);
        }

        & a {
          color: var(--brand-green);
          background-color: var(--brand-yellow);
          width: 33%;
          min-width: 250px;
          max-width: 400px;
          min-height: 48px;
          display: block;
          display: flex;
          justify-content: center;
          align-items: center;
          border-radius: 4px;
          border: none;
          outline: none;
          text-decoration: none;

          &:hover {
            color: var(--brand-white);
            background-color: var(--brand-pink);
          }
        }
      }



      & .feature-container {
        display: flex;
        flex-wrap: nowrap;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        gap: 16px;

        border: 1px var(--brand-green-faded);
        border-style: none solid;
        padding: 16px;

        /* See Global definitions under Body for majority of ".carousel-card" styling */
        & .carousel-card {
          width: 240px;

          /* Hide Description on homepage */
          &>div>div:nth-of-type(1)>div:nth-of-type(1) {
            display: none;
          }
        }
      }
    }

    & #homepage-resource-hero {
      display: flex;
      justify-content: center;
      flex-wrap: wrap-reverse;
      padding: 32px 0;
      gap: 8px;


      & .text-container {
        display: flex;
        max-width: 100%;
        justify-content: space-between;
        color: var(--brand-green);
        flex-direction: column;
        text-align: center;

        & h3 {
          font-weight: bolder;
          font-size: 64px;
        }

        & a {
          color: var(--brand-green);
          background-color: var(--brand-yellow);
          width: auto;
          min-height: 48px;
          display: block;
          display: flex;
          justify-content: center;
          align-items: center;
          border-radius: 4px;
          border: none;
          outline: none;
          text-decoration: none;

          &:hover {
            color: var(--brand-white);
            background-color: var(--brand-pink);
          }
        }
      }

      & .visual-container {
        width: min-content;
        margin-bottom: -24px;

        & a {
          color: gainsboro;
          font-size: 75%;
          text-align: center;
          display: block;
          bottom: 24px;
          position: relative;
        }
      }
    }
  }

  @media (max-width: 556px) {
    #homepage {
      & #homepage-hero .title-bookends {
        display: none;
      }
      & .feature-section .feature-section-label {
        text-align: center;
      }

      & .feature-section .feature-section-button {
        max-width: 100%;
      }
    }
  }

  /* A-Z Resources Page Styling */
  #az-resources {
    & h1,
    & h2 {
      font-weight: 400;
      font-family: var(--header-font-family);
      color: var(--brand-green);
      text-align: center;
      margin: auto 0;
      border: none;
    }

    & h1 {
      font-size: 64px;
    }

    & #s-lg-az-result-count {
      font-size: 32px;
    }

    /* Relabel "Featured Databases" > "Featured Resources" */
    & .s-lib-public-side-header h2.pad-bottom-sm {
      font-size: 0px;

      &::after {
        content: "Featured Resources";
        font-size: 32px;
      }
    }

    & .container {
      display: flex;
      flex-wrap: wrap;
      gap: 16px
    }

    & #filter {
      width: 25%;
      flex: 1 0 auto;
      min-width: 230px;

      & #filter-heading {
        display: inline-flex;
        justify-content: space-between;
        width: 100%;
        padding-bottom: 8px;
        cursor: default;

        & button {
          color: var(--brand-green);
          background-color: var(--brand-yellow);
          border: none;
          cursor: pointer;

          &:hover {
            color: var(--brand-white);
            background-color: var(--brand-pink);
          }
        }
      }

      & nav {
        display: flex;
        flex-direction: column;

        & li {
          list-style-type: none;

          & h3 {
            font: 16px 400 var(--bs-body-font-family);
            text-transform: uppercase;
            text-decoration: none;
            padding: 8px;
            color: var(--brand-green);
            border-top: 1px solid var(--brand-green-faded);
          }

          & #search-form {
            display: flex;
            padding: 8px 0;
 
            & input {
              border-radius: 6px 0 0 6px;
              border-color: var(--brand-green-faded);
              padding: 8px;
              &::placeholder {
                color: var(--brand-green-faded);

                &:hover {
                  color: var(--brand-pink) !important;
                }
              }
            }
            & button {
              color: black;
              border-radius: 0 6px 6px 0;
              height: 42px;
              border-color: var(--brand-green-faded);

              &:hover {
                color: var(--brand-white);
                background-color: var(--brand-pink);
              }
            }
          }

          & #subject-select {
            position: relative;
            overflow: auto;
            height: fit-content;
            width: 100%;
            border: none;
            display: block;

            & option {
              border-radius: 8px;
              padding: 5px;
              cursor: pointer;

              &:active,
              &:checked {
                color: white;
                background: var(--brand-pink) repeat url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABAQMAAAAl21bKAAAiD2lDQ1BpY2MAAGiBrZpXVBVNs/d7ZucMm5w3mU3OOeecJQcJm5wzkpOCKCo5iihJBAUERFFAFMyIoIKKoKICBoyAosDHc56z1nsuzrn7atZ0/6emq7qm1q/vBgDhlIiAyHiYCYDIqIQ4RzNDmpu7Bw2zCAgAD4iACtT9AuJjJKNCU8D/aRtPAfTPPCPzT67/e93/aoRARnwAABB2T3cHxMQl7OnBvZuanBCzp+H7e37WgBC/wD39ak9Lx+0VCACC+I/f/19N+0cH/6uV/9Fxzo5Ge9ocABox+H9o//+hA0LiIgEQdt5bL/JvDf9lvPF7TZBhREQwZFwUZeLjgv0T4gJkQwMC/kfNfCAeOAIzYAhkAANE7F2MPeUCFPfGeBAHgoE/SNibA4AsCN0b/2fs/xdLYKQk/DMbRcekxoUGhyTQFOUVVKRpJntl05wSoqMYNIlkhn98aAJDkxaSkBCjKScXFRrFCGQExzEY8f6MiOhk2YDoSDktGiPSLzRCk/bPB8f/E6j/v62jy9KcQ0LjaRZGRrSYuOig0L1t9h4jQgMYUfGMQFpiVCAjjuZHM4pj+CWEJjFoRtGRkdFR8TSDhIS4UP/EhNDoKBmnEL84hkFEaDiDpiQrT9sXFRMdl7AXbP1vFprEP4XG71Ua8N9ZAv5NIhsdFyz331vFy/mnysT7ye0lkItgBPtFBEQHMuiy//TiH27/7c5/eIwPUlL8LxdENAQAtbC7+0MUAEwZANvHd3f/NO3ubp/e42EegNGo/8RHnwJAfX3Pf/w/PpFGACj5AAzc/I/PvwqAS4cA4HwWkBiX9K+P6b92AzBAAhRAAwzA7Z0jwt5JIgPK3ktmwAJYARtgB5yAC3ADHsAL+IEAoAFBIAxEgCgQAxKADiSB1B5LskAOyO9RpQSUgQpQA+pAA2gCLaADdIEe0N/jzwgYA5M9Es2BBbAE1sAG2AI74LBHpxNwBvuAK3AD7sADeAFv4AN8gd8emQEgEATtMRqyx2b4HruRIApEg9g9XuP3qE0CySAFpII0kA4yQCbIBjkgF+SBAnAQHAKFoAgUgyPgKCgBx8EJUArKQAWoBFWgGtSCOlAPGkAjOAWawGnQDFpAK2gD7aADnAOdoAtcAN2gB/SCPtAPBsAlcBlcAUPgKhgGI2AUXAdj4CYYBxPgFrgD7oJ74D6YBA/BFHgEZsBj8ATMgjnwDDwH8+AlWACvwGvwBrwF78B7sAJWwQfwCXwGX8BX8A38AD/BBtgEv8AW+AO2wQ7YhSAIhpAQCsJAWAgPESASRIYoEDNEhVghNogD4oS4IR6IDxKAaJAQJAyJQmKQBESHpCAZSBaShxQgJUgZUoXUIQ1IC9KGdCF9yAAygkwgU8gcsoSsIBvIDrKHHCFnaB/kCrlDHpAX5APth/ygAIgBBUMhUBgUAUVB0VAsFA8lQklQCnQASocyoSwoB8qDCqBDUBF0GDoClUDHoVKoHKqEqqAaqA5qgBqhJugM1AK1QWehc1AndB7qhnqhPmgAGoSuQFehYWgUGoNuQhPQbegudB+ahKagaegx9BSag55D89AC9Bpagt5By9Aq9BH6DH2BvkE/oHXoF7QF/YV2YADDMBLGwDiYAJNgCkyFWWF2mBPmhvlgAVgQFoZFYQlYEpaGZWEFWAlWgdVhTVgb1oUNYCPYBDaHLWFr2A52gJ1gF9gN9oC9YV/YDw6Eg+BQOByOhGPgODgRToZT4XQ4E86B8+CDcCFcDB+Fj8OlcAVcBdfC9XAj3AQ3w63wWfgcfB7uhi/C/fAgPARfg0fhMXgcvg3fhR/AD+Fp+Ak8Cz+HX8KL8Bv4LbwMf4A/wV/g7/A6vAlvwdvwLgJGoBBYBB5BQjAhWBBsCE4ED4IfQUMII8QQdIQ0QhahgFBGqCE0EToIPYQhwgRhjrBC2CIcEM4IF4Q7wgvhi/BHMBAhiHBEFCIWkYBIRhxAZCCyEbmIAkQhohhRgjiBKEdUI+oQJxFNiGZEG6ID0YXoRlxEDCAuI64iRhBjiHHEHcR9xEPENOIJYg7xArGIeIN4h1hBfESsIb4j1hG/EH8QO0gYiUJikQQkBUlFsiE5kbxIAaQQUhRJR0oj5ZBKSFWkBlIHqY80QpohLZE2SAekM9IV6Yn0QfojGcgQZAQyGhmPTEKmIjOQ2ch85CFkMbIEWYqsQNYg65GnkGeQbcgO5HlkD7IfOYi8ihxB3kBOIO8iJ5GPkE+Qc8h55CvkEnIZ+QG5hvyOXEf+Rm6jAAqJwqIIKAqKBcWO4kbxo4RQoig6SgalgFJGqaO0UfooI5QZygplh3JEuaA8UD4of1QQKhQViYpFJaJSURmoHFQ+qhB1BHUcVY6qRtWjTqGaUe2oTtQF1EXUJdQQagR1A3ULdQ/1EDWDmkW9QC2illDLqI+oL6ifqF+ov2iARqKxaCKaCc2K5kTzogXRomg6WgatgFZBa6B10YZoU7Ql2hbthHZFe6J90QHoEHQEOgadgE5FZ6Bz0AXow+gSdCm6Cl2HbkQ3o9vRnegedD/6MnoYPYaeQN9DP0Q/Rs+h59Gv0e/QH9Br6O/oTfQfDMAgMTgMCUPFsGN4MAIYEYwERgajgFHFaGL0MEYYc4wNxgHjgvHA+GICMCGYSEwsJgmThsnC5GOKMEcxpZgqTB3mFKYFcxZzHnMRcwlzFXMdM4G5i3mIeYx5hnmJeYNZxnzCfMOsY7Ywu1gkFoclYalYDiwvVhArhpXCymGVsRpYXawR1hxrg3XEumK9sH7YIGw4NgabiD2AzcLmY4uwJdgybDW2AXsa24btxPZgB7BD2FHsOPYu9iH2MfYZdhH7FruKXcP+wP7CbuMQOCyOhKPiOHB8OCGcOE4ap4BTw2njDHCmOGucA84F54nzwwXhwnGxuCRcGi4HdxBXjDuBq8TV4ZpwrbhzuB7cAO4q7jpuAncf9wg3i5vHvcEt4z7jvuN+4bbxMB6LJ+FZ8Fx4frwIno6XwyvjNfF6eBO8Jd4e74L3xPvhg/AR+Dh8Mj4Dn4cvxJfgy/E1+EZ8C74D340fwF/FX8ffwj/Az+Dn8Av4t/gP+C/4dfwfAkTAEIgEKoGTwE8QIUgS5AgqBC2CAcGMYENwIrgTfAmBhDBCDCGJkE7IJRQSSgjlhFrCKUIroZPQSxgkDBNuEu4SpghPCfOEN4RVwhfCOuEPESJiiCQiC5GLSCOKEaWJikR1oi7RhGhFdCC6Er2JgcQwYgwxiZhBzCMWEY8RK4n1xNPEduIFYj9xiDhGvE2cJD4hviC+Jq4Q14jrxD8kiIQlkUlsJB6SIEmCJEtSIWmRDEnmJDvSPpIXyZ8USoomJZHSSXmkItJxUiWpgdRM6iD1kC6RhknjpHukadIz0iLpPekT6QdpiwyRMWQymY3MQxYi08lyZFWyDtmYbEl2ILuRfclB5AhyPPkAOYdcSC4hV5DryWfIHeQe8iB5mDxOvk+eIT8nvyavkL+QN8jbFCSFQKFSuCg0ijhFlqJC0aYYUSwpDhQ3ii8liBJJSaCkUXIpRZTjlGpKI6WV0kXpowxRxih3KY8oc5RFynvKZ8o65S8TggnPRGXiYqIxiTPJMaky6TAZM1kzOTF5MPkzhTLFMKUwZTEdZCphqmBqYGpmOsd0kekK0xjTHaYppjmmRaZlpjWmDaZtZhQzkZmVmYdZmFmSWZFZg9mA2ZzZntmV2Zc5mDmKOYk5g7mA+ShzOXM9czPzOeaLzEPMY8x3maeZnzG/Zl5l/sr8iwqoWCqFykEVoIpTZamqVF2qKdWWuo/qTWVQI6mJ1AxqPvUItZxaT22mdlL7qFepN6n3qY+pL6hL1I/UH9Q/LAgWAgsLCw+LMIsUixKLFosxizWLM4sXSyBLBEsCSzpLPssRlnKWBpYWli6WfpZrLOMsD1iesiywvGdZY9lg2WXFsFJYOVhprBKs8qzqrAasFqwOrB6s/qxhrPGsaax5rEdYy1nrWVtYu1gHWIdZJ1gfss6yvmJdYf3G+psNYsOzUdl42ITZpNmU2XTYTNhs2VzZfNlC2GLYUtly2A6zlbHVsTWzdbL1sw2zTbA9ZJtje8W2yvadbYsdwU5kZ2XnYxdjl2NXY9dnt2B3ZPdgD2CPYE9kz2Q/yH6MvZq9ib2D/SL7EPtN9gfsT9kX2VfYv7FvcSA4iBysHHwcYhxyHOocBhyWHE4cXhwMjiiOZI5sjiKOUo56jhaO8xyXOEY57nBMc7zgeMvxmWOTE3DiOKmcPJwinLKcapz6nBacjpxenAzOKM5kzhzOw5xlnPWcrZwXOAc5xzjvcT7mXOBc5vzKucWF4CJysXMJcNG5FLm0uEy4bLncuPy4wrkSuDK5DnGd4Krlaubq4rrENcp1l2uG6yXXe66vXFvcCG4SNzs3jVuSW4lbh9uU257bgzuAO5I7mTuH+zB3OfdJ7jbuHu4h7nHuSe457jfcn7jXuXd5cDwsPHw84jzyPJo8xjy2PG48/jwRPIk8WTxFPGU8DTxtPD08QzzjPA95nvEs8Xzm2eSFeAm8bLwCvHReJV4dXjNeB15PXgZvDO8B3nzeEt5q3tO8nbwDvNd57/E+4V3kXeX9ybvDh+Wj8vHyifMp8GnxmfDZ83nwBfJF86Xy5fGV8FXznebr4rvEd53vPt9Tvtd8H/nW+QE/np+NX4Bfkl+ZX5ffgt+J34c/hD+eP4O/kL+Mv4G/nb+X/xr/Lf5p/nn+Zf7v/H8FMAJUAV4BcQFFAW0BMwFHAS+BYIE4gXSBQwKlAg0CbQK9AtcEbgtMC7wUWBH4IbBDw9JYaPw0Ok2ZpkezpDnTfGlhtERaNq2YVklronXSLtHGaA9oc7Ql2hrttyBSkCLILSgqKC+oJWgq6CDoJRgsGCeYKVgkWC7YKNgh2C84KnhfcFbwjeBnwV9CSCGKELeQqJC8kLaQmZCjkI9QqFCCUJZQsVClUJNQl9Cg0A2hh0LPhd4LfRP6K4wVZhEWEJYUVhE2ELYWdhMOEI4WPiB8UPiEcINwu3Cf8IjwPeGnwm+E14R/i6BEmER4RSRElET0RKxEXET8RaJEUkUKRE6I1Iu0i/SJjIjcE5kVWRJZE9kSRYtSRflF6aIqogaiNqLuogzRGNF00ULRctFTop2ig6I3RadE50WXRX+I7ooRxDjEhMXkxLTEzMScxHzFwsWSxfLFjovVi7WL9YmNit0XmxN7K/ZVbFscJ84mLiguI64hbiruKO4jHiaeJJ4nfky8TrxNvE98VPy++DPxd+LfxLcl8BLsEsISchJaEuYSzhL7JSIlUiUOSpRKnJQ4J3FJ4qbElMRLiVWJDTpMp9B56BJ0ZboB3YbuQQ+mx9Oz6UfoNfRWei99hH6fPkd/R/9G35EkSHJKikgqSOpKWkq6SgZKxkpmSB6WrJJsluyRvCZ5V3JW8q3kN8kdKbwUh5SIlIKUrpSVlJsUQypOKkvqiFSNVItUr9SI1H2pZ1LvpX5IQ9JkaR5pCWkVaUNpO2kv6VDpJOk86ePSJ6XPSQ9Kj0tPSy9Kf5beksHIsMoIysjJaMtYyLjIBMrEymTKFMvUyLTKXJS5LjMp80JmVWZDFinLLMsvKy2rIWsm6yzrJxstmy57WLZKtkW2V3ZU9oHsC9kV2Q05hByzHL+ctJymnJncPjl/uRi5TLliuRq5Nrk+uTG5KbmXch/lfsuj5VnlheTl5HXkreTd5YPlE+Rz5Y/Ln5TvlL8sf0v+ifyS/Df5XQWSAreChIKqgrGCo8J+hSiFdIXDCtUKrQp9CmMKUwoLCp8UthSxiuyKIoqKivqKtopeimGKqYqHFCsUzyj2KI4oPlCcV/yg+EsJrcSqJKykoKSnZKPkpRSmlKJ0UKlC6YxSj9Ko0qTSvNJHpd/KGGV2ZRFlJWUDZTtlH+UI5TTlIuVq5VblfuUbytPKr5S/KG+rEFW4VegqaiqmKs4qASpxKtkqx1QaVDpVhlTuqMypLKusqyJVWVQFVeVV9VRtVb1Uw1UPqBapVqm2qvar3lSdUX2t+lV1V42sxqcmraalZqHmphaslqRWoFaudkatV+262pTaotqa2rY6UZ1HXVJdQ91c3VU9SD1RPV+9TP20eo/6dfUp9UX1NfVtDaIGj4aUhqaGhYabRrBGssZBjQqNZo0+jRsa0xqvNb5pAk2KpoCmrKaOpo2ml2a4ZprmYc1azbOag5q3NWc1lzU3tNBabFqiWspaxlpOWgFacVq5Wie0mrS6tUa1prQWtb5o7WiTtfm1ZbR1tG20vbQjtNO1i7XrtM9pX9G+q/1c+4P2bx2cDpcOXUdDx1zHTSdEJ0WnUKdap03nks4tnVmdZZ1NXYwuh664rpquma6rbrBusu4h3SrdNt1Lurd0Z3WXdTf1MHoceuJ6anpmeq56wXopeoV61XrteoN6t/We6a3q/dbH6XPpS+pr6lvqe+iH66fpF+vX63fqX9V/oP9S/7P+jgHZgN9AzkDPwM5gv0GMQY7BCYPTBr0GNwxmDN4a/DREGbIZihmqGpoZuhqGGKYYFhnWGnYYDhneM5w3/Gy4bUQ2EjCSM9I3cjDyM4ozyjMqN2o26jeaMJo1Wjb6ZYwz5jaWMtYytjb2No4yzjI+btxk3Gs8Zjxj/NZ43QRtwmEiYaJhYmniaRJhkmFSYtJo0m1y3WTaZMnkpynKlMNUwlTD1NLU0zTCNMP0mOkp0x7TMdMZ07emG2YYM04zupmWmbWZt1mUWbbZCbPTZn1m42ZPzVbMfpvjzXnNZcz1zO3N/czjzfPNK83bzC+b3zWfN/9svmvBZCFkoWRhYuFiEWJxwKLYosHivMWoxbTFksW6JdqS01LSUsvSxtLXMtYy17LcstXykuUdyxeWny13rZishKyUrUyt3KxCrdKsjlo1WvVY3bB6YrVs9dsab81rLWutb+1oHWidZF1oXWvdaT1sPWX9xvqnDdqGy0bKRsfGzsbPJt6mwKbK5qzNVZtJm1c2322Rthy2dFstWxtbX9s423zbStuztkO2D2wXbb/bIe3Y7eh2Wna2dvvt4uwK7KrsOuyu2k3avbb7YY+257SXstext7f3t0+0P2Rfa99lP2I/bf/WftMB58DrIOdg4ODsEOyQ6nDEodGhx+Gmw6zDqsNfR4qjkKOyo5mjh2OkY7ZjqWOL46DjPccFx29OSCd2J7qTtpOdk79TolOhU53TeafrTo+dlp22nEnONGclZ1Nnd+cI5yznUucW50Hne84Lzt/3ofZx7pPap7vPYR9jX8q+4n0n9/XsG983t+/jvh0Xqouoi7qLlYuvS5xLgUuNS6fLiMuMy3uXLVeSK81V2dXM1dM1yjXXtcL1rOtV1ynXJddNN7wbv5uCm4mbm1uEW7ZbmVub2xW3Sbc3buvuOHc+d3l3Y3c393D3LPcy9zb3K+6T7m/cNzxwHnweCh4mHu4eER7ZHuUe7R5XPaY83nr88iR4CngqeZp5enpGe+Z5Vnme8xzxnPFc9vzjRfES9lLzsvLa75XgVehV79XtddNrzuuTN+TN5k331vF28GZ4H/Au8T7tPeB9z3vR+4cP1ofXR97H2MfdJ9In16fSp8NnxGfGZ9nnry+Tr6ivhq+tr79vsm+x7ynfPt87vi99v+9H7+fZL7ffeL/b/sj9ufsr95/bP7L/8f7V/dt+VD9xPy0/ez+G3wG/Er8zfoN+D/xe+234E/xp/ir+Fv4+/vH+hf4N/r3+t/xf+H8NQAVwB8gFGAe4B0QF5AVUB3QFjAXMBnwKhALZA6UC9QP3BYYFZgVWBHYEjgQ+DlwN3GGwMOgMXYYTI4SRwShjtDOuMaYZK4ztIGqQeJBOkGNQcFBGUGlQW9C1oOmglaDtYGqwRLBOsFNwSHBmcFnw2eDh4MfBq8G7IawhkiF6IftCwkKyQypDzoVcD3ka8ikUDuUIlQk1CnULjQrND60JvRA6Hvoi9GsYOow3TDHMPMw7LD6sKKwxrD/sbtirsI1wYrhQuHq4bXhg+IHw4+Gt4VfDp8NXwnciWCMkI/QjXCIiInIjqiPOR9yMeB7xNRIdyRupFGkR6RuZGFkc2RQ5GDkZ+TZyK4o5SjxKJ8opKiwqO6oyqivqRtSzqK/R6GjeaKVoi+j90UnRR6LPRF+Onop+H70dwxIjGaMf4xoTGZMfUxvTE3MrZiHmZywhVihWPdYuNig2PbYstiN2NHY2di0OGccTpxhnHucblxR3NK457krco7iVuN149njpeKN4j/jY+ML4xviB+Afxb+O3EpgTJBL0ElwSIhPyE+oSehPuJLxK2EwkJ4ol6iQ6J4Yn5ibWJHYn3kpcSNxIIiWJJGklOSaFJeUkVSddSLqVtJC0nkxMFknWSnZMDkvOSa5O7k6+lbyQvJFCShFN0U5xTglPyU2pTelJuZPyKuVXKiVVPFU31SU1KrUgtSG1L/V+6lLqnwMsByQPGB7wOBB7oOhA04HBA1MHVtJAGkeaXJpZmm9aUlpJWmvacNrTtLV0VDpfukq6TTojPSO9Ir0rfTx9Pv1nBjFDJEM7wzkjIiM/oz6jL+NBxruM7Uy2TJlMk0zvzMTMo5ktmcOZTzPXstBZ/FlqWXZZwVlZWVVZ3Vm3s15l/c5mzqZnG2R7ZMdlH84+kz2U/Tj7Uw4yhy9HJcc2JygnK6cqpzvnds7rnN+51FzJXKNcz9yE3CO5LbnDuU9zv+Rh8mh5GnkOeWF5eXl1eX15D/Le5e3kc+TL55vn++UfyC/L78y/mf8yf6OAUiBRYFDgURBXUFzQXHCt4GnBl4PYg4IHNQ86HYw4WHDw5MFLB6cOrh6CD/EcUj5kcyj4UPahmkO9h+4dentou5CjUL7QotC/MK2wovB84a3CV4VbRSxF0kWmRb5FKUUnis4V3SxaKNo8zHRY8rDRYe/DSYePHT57eOzw/OH1YkqxRLFhsWdxYnFJcXvxWPGL4vUj5CMSRwyPeB5JPHLsSPuRsSPzR9aPUo7Sjxoe9TqadPT40bNHbxx9eXSzhLlEqsS4xKckpaS0pLNkouRVydYxlmMyx8yO+R1LO1Zx7MKxO8eWjm0f5ziucNzqOON41vHa433HJ4+vnIBP8J5QPWF/IvxEwYnGE5dPzJxYK8WWCpVql7qWxpYWl7aWjpY+L/1ZRimjlxmX+ZSllJWVdZXdLntT9reco1yh3Lo8qDynvK58oHyq/GMFqoJWoVWxryKm4nBFS8VoxfOK9UpKpWSlSaVv5YHKisruyruV76pAFU+VSpV9VXjVwaqmqqGqp1XfqonV4tWG1d7VydWl1V3Vt6uXqndquGqUa+xqwmoKak7VDNU8rflWS6wVrzWs9alNrS2vvVB7t/ZdHajjrVOrc6yLrCusa64bqXtet17PXC9db1YfUJ9ZX1PfXz9V/7EB0yDUoNPg3pDQcLzhXMNEw5uG7ZNcJ5VP2p8MP3no5OmTwyefn1xvZG6UbjRvDGjMaqxrHGicblw7hTslesrglNeplFPlp7pP3Tu13IRoEmjSbHJpimsqaepommh63bR9muu0ymmH05Gni063nL5++uXp32fYziicsTkTeqbgTNOZa2eenVlvZm6WabZoZjTnNJ9svtL8tPl7C7lFssWsJaAlq6WuZbDlccvXVmIrvdWk1a81s7W2daB1pvVLG6FNos24bX9bRltN20DbdNuXdkK7RLtxu197Rntt+0D7TPuXs8Sz9LMmZ/3PZp6tOzt49vHZbx3kDskOs47AjuyOho4rHbMdP84xnZM5Z3ku+FzeuVPnrp17fm6zk7VTvtOmM6zzUGdz5/XOhc4/XZxdKl2OXdFdR7rOdk10LZ0H5/nOa553PZ9wvvT8hfP3z69eQF8QvqB/wedC2oXqC/0XZi587SZ1S3abdzO6c7sbu691P+/e7GHrUeyx74nsOdzT3jPes9QLevl7tXrde5N6y3t7eh/2frqIvyh+0eSi/8XsiycvDl18dnGjj7VPsc+uL7KvuK+9b6LvbT/cL9Cv0+/Zn9pf2d/XP93/dYA8ID1gMRA8UDBwZuD6wOLA9iWeSxqXXC8lXiq71HPp4aXPg4RB+qDZIGMwb7BpcGTw5eCfy1yX1S+7XE64XHq5+/Lk5c9XCFfoV8yuBF3Jv3L6yuiVxSvbQzxDmkNuQ0lDFUMXhx4Nfb1Kvipz1epq2NXCq61Xx68uXYOv0a7pXfO+ln6t7trla3PXNobZhpWGHYdjh48Nnx9+MPxxBD9CHzEbCRopGGkeGRt5PQpGBUZ1R71G00ZrRy+Pzo1uXme7rnzd6Xrc9RPXu68/vL42RhqTHrMaCxsrGmsfuzX2/gbqhsgNoxv+N3JunLoxemPxxs5NvpvaNz1vpt2svXn55tzNzXGOcdXxfeOJ4+XjF8enx79PME/IT9hPRE8cmzg/8WDi8y3iLelbVrfCbx2+1XHrzq3V29jbErfNbgffPni79fb47Xd3UHdE7hjfCbyTd+fMnRt33tyF7wrdNbjrdzfnbtPd0buv7oF7tHv693zvZd1rvDdyb/He7n2B+3r3fe5n3j95f/j+wv2dB/wPdB/4PMh8cPLB8IOFBzuTApN6k76TWZONkyOTi5O7D2kP9R/uf5j98NTD6w9fT0FTglOGU/5TuVOnp25MLT1CPBJ5ZPyI8ajgUcujiUfvpzHT4tNm0yHThdNnp+9Mf5jBz0jNWM9EzByd6ZqZnFl7THks/9j+cezj0se9j2ce/3zC+kTlicuT5CdVTwafPHuy9ZT7qdZTr6cZT08+HXm6OAtmBWcNZwNm82dbZidml+ewc/Q5y7nwuSNzXXOTc1+eMT1TeOb4LP5Z+bP+Z0+f/XrO9Vzzuefz9Ocnn488f/UCeiH0wvgF48XBF+0v7rz4ME+Yl5m3nY+ePzHfO/94fv0l+0v1l+4v017Wvxx+ubgALQgtGC8wFg4ttC/cXfi0SFqUW7RfjFssX+xfnF38/Yr7lfYrn1dZr5pe3Xj17jX6tcRry9cRr4++vvD60esfb9jeqL1xf3PgTf2b4TevluAlkSXTpZClw0udS5NLX99S3yq/dXmb8rb27dW3C++gd8LvTN4Fvyt6d+7dg3df31PfK793eZ/6vu79tfeLy/CyyLLpcuhy8XLX8tTy9xXWFbUV95W0lZMroytLq6hViVXL1cjVY6u9q49XNz9wfdD+4PMh50Pzh4kPqx8JH2U/OnyM/1j58fLH+Y87nwQ/GX8K+lT0qfPTw0/fP7N+Vvvs8Tnj86nPNz6/W8OuSa3ZrsWula9dWnu+tv2F9sXoS9CXoi+dXx5++f6V7av6V8+vmV+bvo5/XflG+Cb7zeFbwrfqb0PfFr5D30W+m38P/17yvef7k++/fvD80Pvh/6Pgx9kf9398/cnyU/Wnx8+Mn00/b/5cWSesy607riet16xfW3+1gdwQ37DaiN4o3RjYeLaxvSm4abwZsnlks3tzZnPzF88v3V/+vw7+6vg1+evbb7bfGr+9f+f8bvl95/enLaYt5S23rfStU1s3t1b+EP/I/3H+k/Kn/s/on7d/sX+l/9r/Tfxb8/fa39fbqG36ts123Hbl9pXthR14R3zHaid6p3xncGd+F+yK7lrsRu6W7g7svtjd/fe/kj1D/DOcmQXAOR0A6wcA1NQCIBYMAMXr/wGtop1jonR1bAAAAANQTFRF8nrSrDe44AAAAAlwSFlzAAAk6AAAJOgBgmMFHAAAAApJREFUCB1jYAAAAAIAAc/INeUAAAAASUVORK5CYII=");
              }

              &:not(:active, :checked):hover {
                color: var(--brand-pink);
              }
            }
          }
        }
      }

    }

    & #resource-results {
      min-width: 300px;
      flex: 1 0 auto;
      width: 70%;
      & #s-lg-az-reset {
        margin: 16px auto;
        display: block;
        padding: 8px;
        background: var(--brand-yellow);
        color: var(--brand-green);
      }
      
      & .s-lg-az-result {
        color: var(--brand-green);
        padding: 8px;
        border: solid var(--brand-green-faded);
        min-height: 60px;
        border-width: 1px 0 0 0;

        & a,
        & button {
          font-size: 16px;
          font-weight: 500;
          color: black;
          text-decoration-color: rgba(0, 0, 0, .33);
          padding: 0 10px;

          &:hover {
            color: var(--brand-pink);
            text-decoration: none;
          }
        }

        & .s-lg-az-result-badges {
          float: right;
          color: var(--brand-pink);
          font-weight: 400;
        }
      }

      & #featured-resource-list #s-lg-az-popular {
        font-size: 0px;
        display: flex !important;
        flex-direction: row;
        gap: 16px;
        overflow-x: auto;
        border: 1px var(--brand-green-faded);
        border-style: none solid;
        padding: 16px 0;

        & .s-lg-az-result {
          font-size: 16px;
          width: 400px;
          flex: 0 0 auto;
          padding: 8px;
          border: 1px solid var(--brand-green-faded);
          border-radius: 8px;
          width: 240px;
          color: var(--brand-green);
          height: 150px;
          box-shadow: 0px 2px 2px var(--brand-green-faded);
          
          & .s-lg-label-moreinfo {
            display: none;
          }
          & div:nth-of-type(6) {
            display: none
          }
        }
      }

      /* Alphabetical Result Container */
      & .s-lg-db-panel {
        margin-bottom: 0;
      }
    }

    & .fa-external-link
    /* Open in new tab Icon*/
    ,
    & .s-lg-az-result-share,
    & #featured-resource-list .s-lg-az-result-badges,
    & #resource-filter .navbar-header,
    & h3.s-lg-db-panel-title

    /* Alphabetical Result Container Title */
      {
      display: none !important;
    }
  }

  /* Guide Page Styling */

  #guide,
  #s-lg-guide-main,
  .cke_editable_themed {
    font-family: var(--bs-body-font-family);

    /* Guide Tabs - remove underline */
    & #s-lg-tabs-container .nav-tabs>li>a {
      text-decoration: none;
    }

    /* Reformat google embeds to display properly. */
    & .s-lg-widget>iframe {
      margin: auto !important;
      display: block !important;
    }

    & #s-lg-sb-guides .pull-left {
      float: none !important;
    }

    /* Guide Header */
    & #s-lg-guide-header {
      padding-top: 64px;

      /* Hide "Date:" and "Subject" labels, it can be inferred from content. */
      & .s-lg-guide-label {
        display: none;
      }

      /* title */
      & #s-lg-guide-name {
        font-size: 36px;
        color: var(--brand-green);
      }

      /* date-modified */
      & #s-lg-guide-header-updated {
        font-size: 18px;
      }

      /* subject labels */
      & #s-lg-guide-header-subjects a {
        color: var(--brand-green);
        border-radius: 8px;
        margin: 1px;
        padding: 0 6px;
        display: inline-block;
        outline: solid 1px var(--brand-green-faded);
        outline-offset: -1px;
        text-decoration: none;
        font-size: 14px;

        &:hover {
          color: var(--brand-white);
          background: var(--brand-pink);
        }
      }
    }
    
    & #s-lg-tabs-container .nav-tabs,
    & .s-lib-jqtabs .nav-tabs {
      padding: 3px 3px 0px 3px;
      overflow: hidden;

      & a {
        padding: 3px 3px 0px 3px;
        background: white;
        color: black;
        float: none;
        border-top-left-radius: 4px;
        border-top-right-radius: 4px;
        
        &.active {
          background: var(--brand-green);
          color: white;
        }

        &:not(.active):hover {
          background-color: var(--brand-pink);
          color: white;
        }
      }

      /* Standard Tab */
      &>li>a {
        outline: solid 1px var(--brand-green-faded);
        padding-bottom: 24px;
      }

      /* Dropdown Sublist Tab */
      &>li>ul {
        overflow: hidden;

        & a {
          white-space: nowrap;
          margin: 4px;
          display: block;
        }
      }
    }
    & .s-lib-jqtabs .nav-tabs { 
      height: 48px; 

    }
    /* Remove tiny box title - Phillip's request */
    .s-lib-box-title {
      display: none;
    }

    & #s-lg-guide-main {
      padding: 0;
    }

    & h3,
    & h4 {
      padding: 4px;
      width: 100%;
      display: inline-block;
    }

    & h3 {
      color: var(--brand-green);
      border: 6px var(--brand-yellow);
      border-style: double none;
    }

    & h4 {
      padding-left: 24px;
      border-bottom: double 6px var(--brand-pink);
    }

    & small {
      color: #a9a9a9;

      & a {
        color: #6699ff;
      }
    }

    & strong {
      font-weight: bold;
    }
  }

  /* Guide Edit Styling */
  body.s-lg-guide-body:has(header) {
    padding-top: 60px;
    font-size: medium;

    & header {
      padding: 0;
    }

    & .s-lg-admin-guide-page-nav {
      width: 100%;

      & .nav {
        flex-direction: row;

        & .dropdown-menu {
          position: absolute;
        }
      }
    }
    & .s-lib-box-title {
      display: block !important;
    }
    & a {
      text-decoration: none;
    }
  }

  /* Subject Page Styling */
  #subject,
  #subject-landing {
    & .s-lg-gtitle {
      font-size: 16px;
      font-weight: 500;
      color: var(--brand-black);
      line-height: 140%;
      padding: 8px 0px;
      font-family: var(--bs-body-font-family);

      & a {
        font-size: 16px;
        font-weight: 500;
        color: black;
        text-decoration-color: rgba(0, 0, 0, .33);

        &:hover {
          color: var(--brand-pink);
          text-decoration: none;
        }
      }
    }

    /* Only display sections that contain results */
    #s-lib-public-main>div {
      display: none;
    }

    #s-lib-public-main>div:has(a) {
      display: block;
    }

    & .carousel-card {
      margin: 16px 0;
    }
  }

  /* Search Page Styling */
  #search {
    & .hidden {
      display: none;
    }
  }
</style>

<script> // Add LibGuides Styling, and remove conflicting Bootstrap 5 script on Admin Guide Edit page.
  document.addEventListener("DOMContentLoaded", function () {
    var element
    const isAdmin = window.location.pathname.indexOf("admin") != -1
    if (isAdmin) {
      element = '<link rel="stylesheet" href="https://static-assets-ca.libguides.com/web/css3.14.3/lg-public.min.css">'
      $('#s-lib-bc').show();
    } else {
      element = '<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"> \<\/script>';
    }
    $('head').append(element);
  });
</script>

<script> // Scrape default guide display, and add them to featured carousel sections.
  function appendCards(titleSelector, inputElementSelector, inputPHPSelector, outputElementSelector) {
    // 1. iterate over default "all guides" list sorted by recency, selecting items starting with "titleSelector" character
    output = $(inputElementSelector)

    if (titleSelector != "") {
      output = output.filter(function (index) {
        return $(this).find('a').text().charAt(0) == titleSelector;
      });
    }

    if (output.length == 0) {
      console.log("No pages matched selector: '", titleSelector, "'.")
      return false;
    }

    // 2. Extract links to resource from each item
    var titleList = Array(output.length)
    output.find('a').each(function (i, value) {
      titleList[i] = $(this).text().replace(/(\r\n|\n|\r|^!|^\*)/gm, "").replace(/\s+/g, ' ');
    });

    // 3. Extract php requests from each item.
    var phpList = Array(titleList.length)
    output.find(inputPHPSelector).each(function (i, value) {
      phpList[i] = $(this).attr('data-ajload');
    });

    // 4. Request php "more information" response for each link as html.
    var html = Array(phpList.length);
    var allAJAX = phpList.map((link, index) => {
      return $.ajax({
        type: "GET",
        url: link,
        async: true,
        success: function (response) {
          /* Remove garbage formatting from php result. (We are using it in an unintended way.)*/
          noNewlines = response.replace(/(?:\\n)/g, '');
          fixElements = noNewlines.replace(/(?:\\\/)/g, '/');
          fixLinks = fixElements.replace(/(?:\\\"\/|\\\")/g, '');
          cutStyle = fixLinks.replace(/(?:style=.*?;>)/g, '>');
          cutHeader = cutStyle.substring(
            cutStyle.indexOf("-->") + 3,
            cutStyle.lastIndexOf("<span>")
          );

          /* Extract Variables */
          link_regular_expression = /window\.location\.href='(.*)'/g /* Select the guide's url from the default button */
          link = link_regular_expression.exec(cutHeader)[1];
          id_regular_expression = /\.com\/(?:(?:c\.php\?g=([0-9]+))|(.+))/g /* Select the guide's default id from the url, if does not have a custom url assigned. */
          guide_id = id_regular_expression.exec(link).filter(Boolean)[1].replace("/", "_");
          imageSource = "https://d1qywhc7l90rsa.cloudfront.net/customers/10289/images/" + guide_id + ".jpg"
          image = `<img draggable='false' class="carousel-card-image" src="` + imageSource + `" onerror="this.onerror=null; this.src='https://d1qywhc7l90rsa.cloudfront.net/customers/10289/images/Default_Featured.jpg'" alt="" width="222"height="148">`
          title = "<h3 class='carousel-card-title'><a draggable='false' target='_blank' href='" + link + "'>" + titleList[index] + "</a></h3>"

          /* Style Tags & make links open in new tab*/
          removeDelinator = cutHeader.replace(/<\/a>,/g, '</a>') /* Remove commas seperating each subject */
          removeTopLevelPrefix = removeDelinator.replace(/\>[A-Za-z0-9]+?\: /g, '>') /* Remove the top-level prefix from sub-level headings (e.g. "Posts: How To" becomes "How To" */
          removeTopLevelSubjects = removeTopLevelPrefix.replace(/<a.{20,50}>Collaboration<\/a>/g, "").replace(/<a.{20,50}>Posts<\/a>/g, "") /* Remove the two top-level headings (e.g. "Posts" is removed) */
          alterLinks = removeTopLevelSubjects.replace(/<a/g, "<a draggable='false' target='_blank'")

          /* Save the card's html to it's index in array. */
          html[index] = "<div class='carousel-card'>" + image + title + alterLinks + "</div></div></div>";
        }
      });
    });

    // 5. Append results to featured section
    Promise.all(allAJAX).then(function () {
      html.forEach((element) =>
        $(outputElementSelector).append(element)
      );
    });

    return true
  }
</script>

<script defer> // Scrape admin login link
  $(window).on('load', function () {
    link = $("#s-lib-footer-login-link a").attr('href')
    $("#admin-login-link").attr('href', link);
  });
</script>


<script>
    var springStats = springStats || {};
    springStats.saConfig = springStats.saConfig || {
        site_id: 26075,
        tracking_parameters: {"_st_site_id":26075},
        tracking_server_host: "libguides-proc-ca.springyaws.com"
    };
</script>
<script  src="https://static-assets-ca.libguides.com/web/js/sa.min.js?3116"></script>


<script type="text/javascript">
    var title_base = "A-Z Databases";
    var search_data = {"terms":""};

    springSpace.publicObj = new springSpace.public.Public({
        constant: {
            PROCESSING: {},
            CONTENT: {}
        }
    });

    jQuery(document).ready(function () {
        if (window.history && history.pushState) {
            jQuery(window).bind("popstate", function (e) {
                // Don\'t reload list if this is the result of a skip link hash update.
                if (location.hash !== "#s-lib-public-main" && springSpace.azList.historyEdited) {
                    // location.search will return URL encoded values which will end up causing double-encoding when jQuery sends the loadAzList request.
                    var search_terms = decodeURIComponent(springSpace.Util.getQSParam({
                        name: "q",
                        qs: location.search
                    }));

                    springSpace.publicObj.loadAzList({
                        first: springSpace.Util.getQSParam({name: "a", qs: location.search}),
                        subject_id: springSpace.Util.getQSParam({name: "s", qs: location.search}),
                        type_id: springSpace.Util.getQSParam({name: "t", qs: location.search}),
                        vendor_id: springSpace.Util.getQSParam({name: "v", qs: location.search}),
                        access_mode_id: springSpace.Util.getQSParam({name: "am", qs: location.search}),
                        page: springSpace.Util.getQSParam({name: "p", qs: location.search}),
                        search: springSpace.Util.escapeHtml(search_terms),
                        site_id: 26075,
                        action: "back"
                    });
                }
            });
        }

        springSpace.azList.initSelections();

        // note that loadAzList is called with handle_alpha_filter=true so we can apply any passed in first-letter
        // filters after the search is complete
        if (springSpace.publicObj.getSearchTerm() == "") {
            springSpace.publicObj.loadAzList({
                first: "",
                subject_id: "",
                type_id: "",
                vendor_id: "",
                access_mode_id: "",
                page: 0,
                search: search_data.terms,
                site_id: 26075,
                action: "init"
            }, true);
        }
        // else, call filterAzBySearch so the passed in search string will be recorded
        else {
            springSpace.publicObj.filterAzBySearch(26075);
        }
    });

    springSpace.azList = {
        referrer: document.referrer,
        az_preview: "",
        locations: [],
        historyEdited: false,
        is_widget: 0,
        site_domain: "",
        init_filters: {
            subject: "",
            vendor: "",
            type: "",
            alpha: "",
            search: search_data.terms
        },
        letter_selected: "", // "first" alpha letter selecte so we can keep track.
        letter_alpha_map: {
            pound: "#",
            all: ""
        },
        getAlphaMap: function (letter) {
            if (letter == "pound" || letter == "all") {
                return this.letter_alpha_map[letter]
            } else {
                return letter;
            }
        },
        reset: function () {
            this.letter_selected = "";
            jQuery(".s-lg-az-first").removeClass("bold");
            jQuery(".s-lg-az-search").val("");
            springSpace.publicObj.clearAzSelection("s-lg-sel-az-types");
            springSpace.publicObj.clearAzSelection("s-lg-sel-subjects");
            springSpace.publicObj.clearAzSelection("s-lg-sel-az-vendors");
            springSpace.publicObj.clearAzSelection("s-lg-sel-az-access-modes");
            springSpace.publicObj.loadAzList({
                site_id: 26075
            });
        },
        initSelections: function () {
            // subject filter
            if (this.init_filters.subject == 0) {
                springSpace.publicObj.clearAzSelection("s-lg-sel-subjects");
            }

            // type filter
            if (this.init_filters.type == 0) {
                springSpace.publicObj.clearAzSelection("s-lg-sel-az-types");
            }

            // vendor filter
            if (this.init_filters.vendor == 0) {
                springSpace.publicObj.clearAzSelection("s-lg-sel-az-vendors");
            }

            // access modes filter
            if (this.init_filters.access_modes == 0) {
                springSpace.publicObj.clearAzSelection("s-lg-sel-az-access-modes");
            }

            // this.init_filters.alpha must be handled after the search results come back, so handling was moved inside
            // the loadAzList() call itself

            // search term
            if (this.init_filters.search == "") {
                jQuery(".s-lg-az-search").val("");
            } else {
                jQuery(".s-lg-az-search").val(this.init_filters.search);
            }
        }
    };

    
        jQuery(document).ready(function () {
            springSpace.springTrack.trackPage({_st_type_id: '17'});
        });
            springSpace.cookieConsentReadMore = "When you use LibGuides, the system writes several cookies in your browser. These cookies tell us whether and when you are logged in. The cookies are never shared with any third parties. <br \/><br \/>\r\n\r\nIn addition, your IP address and browser info is stored in server logs in order to generate aggregate anonymized usage statistics. Your IP address and login name are also stored in the LibGuides activity log to facilitate troubleshooting. This information is available to Springshare staff only and is only accessed upon institution request. <br \/><br \/>\r\n\r\nWe never share or sell any user information to third parties.";
        springSpace.cookieConsentConfig = {
            placement: 'top',
            consent_message: "This site uses cookies and records your IP address for usage statistics. <a id=\"s-ui-cc-read-more-link\">Read More<\/a>",
            read_more_callback: function () {
                springSpace.UI.alert({
                    height: 400,
                    width: 400,
                    title: "Privacy Notification",
                    content: springSpace.cookieConsentReadMore,
                    focus_on_close: false
                });
            }
        };
        springSpace.cookieConsent.alert(springSpace.cookieConsentConfig);
        
</script>


<!-- BEGIN: Analytics code --><meta name="google-site-verification" content="1LckdEZKvTKKqLIdGZN1azqWE3b3A6uBthibd_W2fio" /><!-- END: Analytics code -->

</head>
<body class="s-lib-public-body">
    <a id="s-lg-public-skiplink" class="alert-info" href="#s-lib-public-main">Skip to Main Content</a>
    <nav id="site-header" class="navbar navbar-expand-xl site-nav">
        <a id="navbar-home-link" class="logo-link" href="/?b=g&d=r" target="_blank" >
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 960.24">
                <path class="cls-2" d="M541.12,848.48c-45-14.58-41.65-74.5-41.65-74.5l-.38.11s1.16,57.89-43.7,72.91c-39.18,13.28-94.79,3.35-165.79-44.48-2.95,4.08-5.29,7.31-6.82,9.44-21.84,30.45-32.3,81.18,10.12,123.95,30.26,30.51,65.64,26.16,119.18,19.58,25.45-3.13,54.29-6.67,86.92-6.67s61.48,3.54,86.94,6.67c53.64,6.59,89.07,10.94,119.34-19.58,55.4-55.87,18.24-112.91,10.23-123.78-1.76-2.39-4.38-5.98-7.72-10.56-72.37,50.87-126.61,60.06-166.67,46.92Z"/>
                <path class="cls-2" d="M990.91,430.37c-36.01-69.96-101.75-52.24-114.56-47.98-3.84,1.28-10.26,3.38-18.73,6.13,23.45,80.58,16.23,135.8-7.89,168.85-27.75,38.31-82.64,19.89-82.64,19.89v.17s50.37,20.46,50.83,67.76c.51,38.41-26.44,87.09-84.51,136.3,4.02,5.52,7.14,9.8,9.06,12.4,22.21,30.18,67.21,55.82,121.01,28.68,38.36-19.36,45.16-54.34,55.45-107.3,4.89-25.17,10.43-53.69,20.51-84.72,10.08-31.03,22.37-57.38,33.21-80.63,22.83-48.97,37.92-81.33,18.26-119.55Z"/>
                <path class="cls-2" d="M672.83,177.6c23.51,32.35.1,70.45-7.73,81.5,8.43-9.64,38.47-39.72,76.61-27.75,37.89,11.73,76.25,51.93,105.34,126.24,9.32-3.03,16.29-5.31,20.19-6.6,35.57-11.79,73.85-46.69,64.67-106.23-6.56-42.47-37.73-59.74-84.91-85.89-22.43-12.43-47.85-26.52-74.24-45.7-26.39-19.17-47.66-39-66.42-56.49-35.01-32.64-59.49-55.47-94.11-55.47-4.47,0-9.1.38-13.94,1.17-77.66,12.64-81.13,80.63-81.04,94.13.03,4.26.04,11.55.04,21.17,84.16,2.55,131.52,26.64,155.54,59.94Z"/>
                <path class="cls-2" d="M252.01,231.51c44.98-14.66,78.53,32.53,78.53,32.53l.1-.14s-28.7-46.17-1.24-84.69c22.83-32.27,75.63-56.21,155.28-60.94,0-10.58-.02-18.44-.04-22.77-.22-37.47-21.58-84.66-81.04-94.33-4.85-.79-9.49-1.17-13.95-1.17-34.6,0-59.04,22.79-93.98,55.38-18.75,17.49-40,37.31-66.4,56.49-26.39,19.17-51.82,33.27-74.26,45.71-47.26,26.2-78.48,43.5-85.04,85.98-11.98,77.77,51.61,102.08,64.48,106.16,3.28,1.04,8.44,2.7,15.11,4.87,28.07-73.19,64.98-111.01,102.45-123.07Z"/>
                <path class="cls-2" d="M176.62,646.4c0-41.89,41.44-61.52,50.94-65.47-9.91,2.47-54.97,11.47-79.95-22.23-24.66-33.01-31.61-91.22-8.39-173.22-6.9-2.24-12.17-3.93-15.37-4.95-9.56-3.05-20.27-4.86-31.33-4.86-30.24,0-63.24,13.57-83.43,52.78-19.66,38.21-4.59,70.51,18.21,119.4,10.84,23.24,23.12,49.57,33.2,80.6,10.08,31.02,15.63,59.56,20.52,84.74,10.31,53.05,17.13,88.09,55.5,107.45,70.25,35.43,113.03-17.54,120.89-28.52,1.5-2.1,3.68-5.12,6.4-8.87-60.96-49.48-87.33-97.58-87.19-136.87Z"/>
                <path class="cls-2" d="M499.14,314.4c1.9-6.86,12.88-41.74,40.43-46.22,31.56-5.13,45.28,23.48,80.44,49.03,35.16,25.55,66.55,29.71,71.43,61.31,4.04,26.23-22.69,46.7-30.44,52.04,8.67-.28,43.4.18,55.76,24.2,14.63,28.43-8.34,50.32-21.77,91.65-13.43,41.34-7.69,72.47-36.23,86.88-27.65,13.94-60.89-14.45-60.89-14.45l-1.83-1.44.98,2.24s16.73,40.39-5.07,62.38c-22.52,22.7-50.43,7.61-93.9,7.61s-71.3,15.08-93.82-7.61c-21.81-21.99-5.07-62.38-5.07-62.38l.43-1.18-.45.4s-33.24,28.4-60.89,14.45c-28.54-14.4-22.83-45.61-36.26-86.95-13.43-41.34-36.38-63.15-21.75-91.58,13.52-26.26,53.69-24.36,57.39-24.12-7.27-4.95-34.92-25.67-30.82-52.3,4.88-31.6,36.33-35.8,71.49-61.35,35.16-25.55,48.82-54.11,80.38-48.99,27.78,4.52,38.71,39.94,40.47,46.38ZM498.33,398.19c-21.62.35-35.81,6.32-41.67,14.6-6.49,9.11.3,20.02.3,20.02l-.02.03s-7.93-11.15-18.56-7.69c-9.66,3.11-19.16,13.45-25.96,33.97-6.34,20.67-4.79,35.24,1.28,43.37,5.96,8.03,16.69,5.81,18.91,5.25-2.14.88-12.05,5.5-12.05,15.48-.04,10.14,7.4,22.77,24.81,35.6,17.69,12.43,31.48,15.08,41.09,11.82,10.6-3.55,10.33-17.23,10.33-17.23l.09-.03s-.79,14.16,9.85,17.61c9.64,3.16,22.75.86,40.32-11.74,17.28-13,25.24-26.17,25.11-36.32-.11-11.18-12.01-16.02-12.01-16.02v-.04s12.97,4.36,19.53-4.7c5.98-8.19,7.58-22.14,1.01-42.74-7.03-20.45-16.86-31.32-26.55-34.32-9.13-2.87-16.28,4.45-18.16,6.63,1.78-2.48,7.51-11.59,1.88-19.33-5.93-8.23-17.89-14.08-39.51-14.22Z"/>
            </svg>
            Senior <br>Learning <br>Commons
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsing-navigation"
            aria-controls="collapsing-navigation" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div id="collapsing-navigation" class="collapse navbar-collapse">
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Resources
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="/az.php" target="_blank">All Resources</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/resources/catalogue" target="_blank">Our Catalogue</a></li>
                        <li><a class="dropdown-item" href="/resources/sora" target="_blank">Sora E-Books</a></li>
                        <li><a class="dropdown-item" href="/orders" target="_blank">Request A Title</a></li>
                        <li><a class="dropdown-item" href="/az.php?s=138977" target="_blank">Resources - Multi-Subject</a></li>
                        <li><a class="dropdown-item" href="/az.php?s=138907" target="_blank">Resources - English</a></li>
                        <li><a class="dropdown-item" href="/az.php?s=138908" target="_blank">Resources - Science</a></li>
                        <li><a class="dropdown-item" href="/az.php?s=138909" target="_blank">Resources - Socials</a></li>
                        <li><a class="dropdown-item" href="/az.php?s=138901" target="_blank">Resources - News</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        How To
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="/how-to" target="_blank">All "How To" Guides</a></li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li><a class="dropdown-item" href="/how-to/assess-reliability" target="_blank">Assess Reliability</a></li>
                        <li><a class="dropdown-item" href="/how-to/research-sources" target="_blank">Searching for Sources</a></li>
                        <li><a class="dropdown-item" href="/how-to/find-your-book" target="_blank">Find Your Next Book</a></li>
                        <li><a class="dropdown-item" href="/how-to/3d-printing" target="_blank">3D Printing</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Reading Lists
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="/reading-lists" target="_blank">All Reading Lists</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/collections/summer" target="_blank">Summer Reading</a></li>
                        <li><a class="dropdown-item" href="/collections/yorkie" target="_blank">Yorkie Reccomendations</a></li>
                        <li><a class="dropdown-item" href="/initiatives/publications" target="_blank">Student Publications</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/collections/anti-islamophobia" target="_blank">Anti Islamophobia</a></li>
                        <li><a class="dropdown-item" href="/collections/asian-heritage" target="_blank">Asian Heritage</a></li>
                        <li><a class="dropdown-item" href="/collections/black-history" target="_blank">Black History</a></li>
                        <li><a class="dropdown-item" href="/collections/first-nations" target="_blank">First Nations</a></li>
                        <li><a class="dropdown-item" href="/c.php?g=747369" target="_blank">Courageous Conversations: Gender</a></li>
                        <li><a class="dropdown-item" href="/collections/gsa" target="_blank">Gender & Sexuality Alliance</a></li>
                        <li><a class="dropdown-item" href="/collections/mental-health" target="_blank">Mental Health</a></li>
                        <li><a class="dropdown-item" href="/collections/neurodiversity" target="_blank">Neurodiveristy</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Collaboration
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="/collaboration" target="_blank">All Collaboration</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/collaboration/2025-26" target="_blank">2025-26 (Current)</a></li>
                        <li><a class="dropdown-item" href="/collaboration/2024-25" target="_blank">2024-25</a></li>
                        <li><a class="dropdown-item" href="/collaboration/2023-24" target="_blank">2023-24</a></li>
                    </ul>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        Student Initiatives
                    </a>
                    <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <li><a class="dropdown-item" href="/initiatives" target="_blank">All Initiatives</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item" href="/initiatives/publications" target="_blank">Student Publications</a></li>
                        <li><a class="dropdown-item" href="/initiatives/model-un" target="_blank">Model UN</a></li>
                        <li><a class="dropdown-item" style="display: none;" href="#">Tutoring</a></li>
                    </ul>
                </li>
            </ul>
            <form id="navbar-search" class="d-flex" action="/srch.php" method="GET">
                <input class="form-control me-2" type="text" name="q" maxlength="260" placeholder="Search" aria-label="Search" role="search">
            </form>
        </div>
</nav>

    <div id="az-resources" class="page-content">
        <h1 class="page-header">Resources</h1>
        <div class="container">
            <div id="filter" class="hide-on-filter">
                <div id="filter-heading">
                    <h2>
                        Filter Resources
                    </h2>
                </div>
                <nav>
                    <li>
                        <h3>By Search</h3>
                        <form id="search-form" role="search"
                            onsubmit="springSpace.publicObj.filterAzBySearch(26075); return false;">
                            <input type="text" class="s-lg-az-search form-control" aria-label="Search for Databases"
                                placeholder="Search for..." maxlength="260">
                            <button class="btn btn-default btn-outline-secondary" type="submit" aria-label="Go">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" width="24px" height="24px">
                                    <path
                                        d="M 13 3 C 7.4889971 3 3 7.4889971 3 13 C 3 18.511003 7.4889971 23 13 23 C 15.396508 23 17.597385 22.148986 19.322266 20.736328 L 25.292969 26.707031 A 1.0001 1.0001 0 1 0 26.707031 25.292969 L 20.736328 19.322266 C 22.148986 17.597385 23 15.396508 23 13 C 23 7.4889971 18.511003 3 13 3 z M 13 5 C 17.430123 5 21 8.5698774 21 13 C 21 17.430123 17.430123 21 13 21 C 8.5698774 21 5 17.430123 5 13 C 5 8.5698774 8.5698774 5 13 5 z" />
                                </svg>
                            </button>
                        </form>
                    </li>
                    <li>
                        <h3>By Subject</h3>
                        <select id="subject-select" size="6"
                            onchange="springSpace.publicObj.filterAzBySubject(jQuery(this).val(), 26075);">
                            <option value="">All Subjects</option>
                            <option value="138907">English</option>
                            <option value="138977">Multi-Subject</option>
                            <option value="138901">News</option>
                            <option value="138908">Science</option>
                            <option value="138909">Socials</option>
                            <!--
                            The options in this select are a static snapshot of what the site 
                            places in the hidden select directly below. If new subjects are added, 
                            look in the hidden element using a web browser's inspect tool.
                            -->
                        </select>
                        <select style="display: none;" size="8" id="s-lg-sel-subjects"
                            class="col-subjects s-lg-sel-subjects" name="s-lg-sel-subjects"
                            onchange="springSpace.publicObj.filterAzBySubject(jQuery(this).val(), 26075);">
                            Database Subject Filter<option value="" selected="">All Subjects</option>
                        </select>
                    </li>
                </nav>
                <div id="original-filter" style="display: none;">
                    <!--The script that filters content checks the original setup somehow to stack categories.-->
                    
<nav class="navbar navbar-expand-lg navbar-default" aria-label="Search filters">
    <div class="container-fluid">
        <div class="navbar-header">
            <button type="button" class="navbar-toggler navbar-toggle collapsed" data-toggle="collapse"
                    data-target="#s-lg-az-nav-1" data-bs-toggle="collapse" data-bs-target="#s-lg-az-nav-1">
                <span class="sr-only">Toggle search filters navigation</span>
                <span class="navbar-toggler-icon"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>

        <div class="collapse navbar-collapse" id="s-lg-az-nav-1">
            <div id="s-lg-az-filters" style="padding-top:15px;">
                <section>
                    <div id="s-lg-az-filter-cols" class="row">
                                                                                    <div id="col-subjects" class="col-subjects col-md-3 center">
                                    <label class="control-label sr-only" for="s-lg-sel-subjects">Database Subject Filter</label><select id="s-lg-sel-subjects" name="s-lg-sel-subjects" class="s-lg-sel-subjects form-control" onChange="springSpace.publicObj.filterAzBySubject(jQuery(this).val(), 26075);"><option value="" selected>All Subjects</option><option value="139197">Subject (0)</option><option value="138907">Subject: English (3)</option><option value="138977">Subject: Multi-Subject (4)</option><option value="138901">Subject: News (6)</option><option value="138908">Subject: Science (1)</option><option value="138909">Subject: Socials (2)</option></select>
                                </div>
                                                                                                                <div id="col-types" class="col-types col-md-3 center">
                                    <label class="control-label sr-only" for="s-lg-sel-az-types">Database Types Filter</label><select id="s-lg-sel-az-types" name="s-lg-sel-az-types" class="s-lg-sel-az-types form-control" onchange="springSpace.publicObj.filterAzByType(jQuery(this).val(), 26075);" data-placeholder="All Database Types"><option value="" selected>All Database Types</option><option value="28812">Digital (14)</option><option value="28809">Fiction (2)</option><option value="28810">Non-Fiction (14)</option><option value="28811">Physical (1)</option></select>
                                </div>
                                                                                                                <div id="col-vendors" class="col-vendors col-md-3 center">
                                    <label class="control-label sr-only" for="s-lg-sel-az-vendors">Database Vendors Filter</label><select id="s-lg-sel-az-vendors" name="s-lg-sel-az-vendors" class="s-lg-sel-az-vendors form-control" onchange="springSpace.publicObj.filterAzByVendor(jQuery(this).val(), 26075);" data-placeholder="All Vendors / Providers"><option value="" selected>All Vendors / Providers</option><option value="74450">Britannica (1)</option><option value="74444">Financial Times (1)</option><option value="74504">Flipster (1)</option><option value="74447">Follett (1)</option><option value="74980">Free (2)</option><option value="74449">Gale (2)</option><option value="74451">Jstor (1)</option><option value="74457">National Film Board (1)</option><option value="74446">New York Times (1)</option><option value="74488">Nikkei (1)</option><option value="74445">Press Reader (1)</option><option value="74448">Sora (1)</option><option value="74454">YHS (1)</option></select>
                                </div>
                                                                                                                <div id="col-search" class="col-md-3 center">
                                    <form role="search"
                                          onsubmit="springSpace.publicObj.filterAzBySearch(26075); return false;">
                                        <div class="form-group">
                                            <label class="control-label sr-only" for="s-lg-az-search">
                                                DATABASES
                                            </label>

                                            <div class="input-group">
                                                <input type="text" class="s-lg-az-search form-control"
                                                       aria-label="Search for Databases"
                                                       placeholder="Search for Databases"
                                                       maxlength="260"/>
                                                <span class="input-group-btn">
                                                    <button class="btn btn-default btn-outline-secondary" type="submit"
                                                            aria-label="Go">
                                                        Go
                                                    </button>
                                                </span>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                                                                        </div>
                </section>
            </div>
        </div>
    </div>
</nav>

                </div>
            </div>
            <div id="resource-results">
                <div id="featured-resource-list" class="hide-on-filter">
                    <div id="s-lg-az-popular-div"><div class="margin-bottom-xlg"><div class="s-lib-public-side-header"><h2 class="pad-bottom-sm">Featured Databases</h2></div><div class="txt pad-top-sm"><div id="s-lg-az-popular-loading" class="bold s-lib-color-lt-grey pad-top-med">Loading...</div><div id="s-lg-az-popular">The most frequently-used databases


<div class="s-lg-az-result
            
            
            "
>
    <div class="s-lg-az-result-title" >   
            <a href="https://yorkhouse.libguides.com/resources/financial-times"  target="_blank"  onclick="return springSpace.springTrack.trackLink({link: this,_st_type_id: &#039;16&#039;,_st_content_id: &#039;37423315&#039;,_st_inc_return: this});">
        Financial Times
            </a><i class="fa fa-fw fa-external-link " 
            title="This link opens in a new window"
    ><span class="sr-only">This link opens in a new window</span></i>
    </div>
    <div class="s-lg-az-result-badges">
        
        
    <span class="margin-left-sm s-lg-az-result-badge-popular label label-primary">
        Featured
    </span>
        
    </div>

            <div class="s-lg-az-result-share" title="Share">
            <button class="btn btn-sm btn-link" onclick="springSpace.publicObj.displayAzShareAlert({
                'id': 37423315,
                'site_id': 26075,
                'name': 'Share',
                'action': 522,
                'btn_text': 'Close'
                });"
            >
                <i class="fa fa-share-alt fa-lg fa-fw" aria-hidden="true"></i>
                <span class="sr-only">This opens a pop-up window to share the URL for this database</span>
            </button>
        </div>
        
        
            <div class="s-lg-az-result-description">Top-rated for international news.</div>
        
    
                    
    <div class="s-lg-label-moreinfo s-lg-label-more-info">
        <button
            class="s-lg-label-more btn btn-sm btn-link"
            aria-expanded="false"
            id="s-lg-7-more-info-database-more-37423315"
            style="display:block;"
            onclick="
                jQuery('#s-lg-7-more-info-database-moreinfo-37423315').toggle();
                jQuery('#s-lg-7-more-info-database-less-37423315').toggle();
                jQuery('#s-lg-7-more-info-database-more-37423315').toggle();">more...</button>
        <button
            class="s-lg-label-less btn btn-sm btn-link"
            aria-expanded="true"
            id="s-lg-7-more-info-database-less-37423315"
            style="display:none;"
            onclick="
                jQuery('#s-lg-7-more-info-database-moreinfo-37423315').toggle();
                jQuery('#s-lg-7-more-info-database-less-37423315').toggle();
                jQuery('#s-lg-7-more-info-database-more-37423315').toggle(); ">less...</button>
    </div>
    <div id="s-lg-7-more-info-database-moreinfo-37423315" class="s-lg-content-more-info " style="display:none;">
        Your first visit to this database must be on-campus, to register your device. After that you can also access FT off-campus.
    </div>
 
    
         
     
</div>


<div class="s-lg-az-result
            
            
            "
>
    <div class="s-lg-az-result-title" >   
            <a href="https://yorkhouse.libguides.com/resources/new-york-times"  target="_blank"  onclick="return springSpace.springTrack.trackLink({link: this,_st_type_id: &#039;16&#039;,_st_content_id: &#039;37423329&#039;,_st_inc_return: this});">
        New York Times
            </a><i class="fa fa-fw fa-external-link " 
            title="This link opens in a new window"
    ><span class="sr-only">This link opens in a new window</span></i>
    </div>
    <div class="s-lg-az-result-badges">
        
        
    <span class="margin-left-sm s-lg-az-result-badge-popular label label-primary">
        Featured
    </span>
        
    </div>

            <div class="s-lg-az-result-share" title="Share">
            <button class="btn btn-sm btn-link" onclick="springSpace.publicObj.displayAzShareAlert({
                'id': 37423329,
                'site_id': 26075,
                'name': 'Share',
                'action': 522,
                'btn_text': 'Close'
                });"
            >
                <i class="fa fa-share-alt fa-lg fa-fw" aria-hidden="true"></i>
                <span class="sr-only">This opens a pop-up window to share the URL for this database</span>
            </button>
        </div>
        
        
            <div class="s-lg-az-result-description"></div>
        
    
                    
    <div class="s-lg-label-moreinfo s-lg-label-more-info">
        <button
            class="s-lg-label-more btn btn-sm btn-link"
            aria-expanded="false"
            id="s-lg-7-more-info-database-more-37423329"
            style="display:block;"
            onclick="
                jQuery('#s-lg-7-more-info-database-moreinfo-37423329').toggle();
                jQuery('#s-lg-7-more-info-database-less-37423329').toggle();
                jQuery('#s-lg-7-more-info-database-more-37423329').toggle();">more...</button>
        <button
            class="s-lg-label-less btn btn-sm btn-link"
            aria-expanded="true"
            id="s-lg-7-more-info-database-less-37423329"
            style="display:none;"
            onclick="
                jQuery('#s-lg-7-more-info-database-moreinfo-37423329').toggle();
                jQuery('#s-lg-7-more-info-database-less-37423329').toggle();
                jQuery('#s-lg-7-more-info-database-more-37423329').toggle(); ">less...</button>
    </div>
    <div id="s-lg-7-more-info-database-moreinfo-37423329" class="s-lg-content-more-info " style="display:none;">
        You can create a free account using your yorkhouse email.
    </div>
 
    
         
     
</div>


<div class="s-lg-az-result
            
            
            "
>
    <div class="s-lg-az-result-title" >   
            <a href="https://yorkhouse.libguides.com/resources/nikkei-asia"  target="_blank"  onclick="return springSpace.springTrack.trackLink({link: this,_st_type_id: &#039;16&#039;,_st_content_id: &#039;37458513&#039;,_st_inc_return: this});">
        Nikkei Asia
            </a><i class="fa fa-fw fa-external-link " 
            title="This link opens in a new window"
    ><span class="sr-only">This link opens in a new window</span></i>
    </div>
    <div class="s-lg-az-result-badges">
        
        
    <span class="margin-left-sm s-lg-az-result-badge-popular label label-primary">
        Featured
    </span>
        
    </div>

            <div class="s-lg-az-result-share" title="Share">
            <button class="btn btn-sm btn-link" onclick="springSpace.publicObj.displayAzShareAlert({
                'id': 37458513,
                'site_id': 26075,
                'name': 'Share',
                'action': 522,
                'btn_text': 'Close'
                });"
            >
                <i class="fa fa-share-alt fa-lg fa-fw" aria-hidden="true"></i>
                <span class="sr-only">This opens a pop-up window to share the URL for this database</span>
            </button>
        </div>
        
        
            <div class="s-lg-az-result-description">Available on-campus only.</div>
        
    
 
    
         
     
</div>


<div class="s-lg-az-result
            
            
            "
>
    <div class="s-lg-az-result-title" >   
            <a href="https://yorkhouse.libguides.com/resources/press-reader"  target="_blank"  onclick="return springSpace.springTrack.trackLink({link: this,_st_type_id: &#039;16&#039;,_st_content_id: &#039;37423316&#039;,_st_inc_return: this});">
        Press Reader
            </a><i class="fa fa-fw fa-external-link " 
            title="This link opens in a new window"
    ><span class="sr-only">This link opens in a new window</span></i>
    </div>
    <div class="s-lg-az-result-badges">
        
        
    <span class="margin-left-sm s-lg-az-result-badge-popular label label-primary">
        Featured
    </span>
        
    </div>

            <div class="s-lg-az-result-share" title="Share">
            <button class="btn btn-sm btn-link" onclick="springSpace.publicObj.displayAzShareAlert({
                'id': 37423316,
                'site_id': 26075,
                'name': 'Share',
                'action': 522,
                'btn_text': 'Close'
                });"
            >
                <i class="fa fa-share-alt fa-lg fa-fw" aria-hidden="true"></i>
                <span class="sr-only">This opens a pop-up window to share the URL for this database</span>
            </button>
        </div>
        
        
            <div class="s-lg-az-result-description">7,000 newspapers & magazines from around the world.</div>
        
    
 
    
         
     
</div></div></div></div></div>
                </div>
                <div id="resource-list">
                    <div id="filter-label">
                        <h2 id="s-lg-az-result-count" aria-live="polite" class="bold s-lib-text-lg pad-right-med"></h2> <button id="s-lg-az-reset" class="btn btn-default btn-sm s-lib-hide" type="button" onclick="springSpace.azList.reset();">Clear Filters/Browse All Databases</button>
                    </div>
                    <div id="s-lg-az-content" class="pad-right-sm">
                        <div class="bold s-lib-color-lt-grey pad-top-med text-center">Loading...</div>
                    </div>
                </div>
            </div>
        </div>
        <script> // Dropdown toggles
            $(document).ready(function () {
                $("[data-toggle='dropdown']").click(function (e) { /* Open/Close Dropdown when clicked */
                    $(this).parents(".dropdown").toggleClass("open");
                    e.stopPropagation();
                });
            });
        </script>
        <script> // Drag to scroll
            document.addEventListener('DOMContentLoaded', function () {
                const ele = document.getElementById('s-lg-az-popular');
                ele.style.cursor = 'grab';

                let pos = { top: 0, left: 0, x: 0, y: 0 };

                const mouseDownHandler = function (e) {
                    ele.style.cursor = 'grabbing';
                    ele.style.userSelect = 'none';

                    pos = {
                        left: ele.scrollLeft,
                        top: ele.scrollTop,
                        // Get the current mouse position
                        x: e.clientX,
                        y: e.clientY,
                    };

                    document.addEventListener('mousemove', mouseMoveHandler);
                    document.addEventListener('mouseup', mouseUpHandler);
                };

                const mouseMoveHandler = function (e) {
                    // How far the mouse has been moved
                    const dx = e.clientX - pos.x;
                    const dy = e.clientY - pos.y;

                    // Scroll the element
                    ele.scrollTop = pos.top - dy;
                    ele.scrollLeft = pos.left - dx;
                };

                const mouseUpHandler = function () {
                    ele.style.cursor = 'grab';
                    ele.style.removeProperty('user-select');

                    document.removeEventListener('mousemove', mouseMoveHandler);
                    document.removeEventListener('mouseup', mouseUpHandler);
                };

                // Attach the handler
                ele.addEventListener('mousedown', mouseDownHandler);
            });
        </script>
        <script> // Add images to cards
            var isUpdating = false
            const observeUrlChange = () => {
                const body = document.querySelector('body');
                const observer = new MutationObserver(mutation => handleMutation());
                observer.observe(body, { childList: true, subtree: true });
            };

            async function handleMutation() {
                if (!isUpdating) {
                    isUpdating = true
                    /* Ensure all elements have an empty image to target */
                    $(".s-lg-az-result:not(:has(.resource-card-image))").each(function (i, elem) {
                        $(this).prepend(`<img class="resource-card-image">`)
                    });

                    /* Grab featured images */
                    var image_array = []
                    $(".s-lg-az-result a").each(function (i, elem) {
                        var title = $(this).text().trim();
                        var imageSource = "https://d1qywhc7l90rsa.cloudfront.net/customers/10289/images/" + title.replace(/( |\/|\"|\'|\’|\&|\(|\))/g, "_") + ".jpg"
                        var image = `<img class="resource-card-image" src="` + imageSource + `" onerror="this.onerror=null; this.width=0;" alt="" width="48"height="48">`
                        image_array.push(image)
                    });

                    /* Push images to all targets */
                    $(".resource-card-image").each(function (i, elem) {
                        $(this).replaceWith(image_array[i])
                    });

                    /* Hide/show featured resources */
                    var is_filtered = $("#s-lg-az-result-count").text().includes("for")
                    if (is_filtered) {
                        $("#featured-resource-list").hide();
                        $("#resource-reset").show();
                    } else {
                        $("#featured-resource-list").show();
                        $("#resource-reset").hide();
                    }
                    /* Relabel Databases found > Resources found */
                    $("#s-lg-az-result-count").text($("#s-lg-az-result-count").text().replace("Database", "Resource"));

                    await new Promise(r => setTimeout(r, 20));
                    isUpdating = false
                }
            }
            window.onload = observeUrlChange;

            // Hotfix for images initially loading while full list has not, leaving full list blank.
            document.addEventListener('DOMContentLoaded', function () {
                setTimeout(handleMutation, 500);
            });
        </script>
    </div>
    <div id="site-footer">
    <div id="general-info">
        <div id="hours-and-map">
            <h2>Visit us on the second floor!</h2>
            <div>
                <img id="map" height="128"
                    src="https://d1qywhc7l90rsa.cloudfront.net/customers/10289/images/footer-image.jpg">
                <table id="hours">
                    <tr>
                        <th>Monday</th>
                        <td>8am - 4pm</td>
                    </tr>
                    <tr>
                        <th>Tuesday</th>
                        <td>8am - 4pm</td>
                    </tr>
                    <tr>
                        <th>Wednesday</th>
                        <td>8am - 4pm</td>
                    </tr>
                    <tr>
                        <th>Thursday</th>
                        <td>8am - 4pm</td>
                    </tr>
                    <tr>
                        <th>Friday</th>
                        <td>8am - 3:30pm</td>
                    </tr>
                </table>
            </div>
        </div>
        <div id="external-links">
            <a class="logo-link" href="https://www.yorkhouse.ca/" target="_blank" >
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 413.56">
                    <defs>
                        <style>
    
                        </style>
                    </defs>
                    <g>
                        <path class="cls-2" d="M233.59,365.11c-19.34-6.27-17.9-32.02-17.9-32.02l-.16.05s.5,24.88-18.78,31.34c-16.84,5.71-40.75,1.44-71.26-19.12-1.27,1.75-2.27,3.14-2.93,4.06-9.39,13.09-13.88,34.89,4.35,53.28,13.01,13.11,28.21,11.24,51.23,8.41,10.94-1.34,23.34-2.87,37.36-2.87s26.43,1.52,37.37,2.87c23.06,2.83,38.28,4.7,51.29-8.41,23.81-24.01,7.84-48.53,4.4-53.2-.76-1.03-1.88-2.57-3.32-4.54-31.11,21.87-54.42,25.82-71.64,20.17Z"/>
                        <path class="cls-2" d="M426.92,185.4c-15.48-30.07-43.74-22.45-49.24-20.62-1.65.55-4.41,1.45-8.05,2.63,10.08,34.64,6.98,58.37-3.39,72.57-11.93,16.47-35.52,8.55-35.52,8.55v.07s21.65,8.79,21.85,29.13c.22,16.51-11.37,37.43-36.32,58.59,1.73,2.37,3.07,4.21,3.89,5.33,9.55,12.97,28.89,23.99,52.02,12.33,16.49-8.32,19.41-23.36,23.83-46.12,2.1-10.82,4.48-23.08,8.82-36.42,4.33-13.34,9.61-24.66,14.27-34.66,9.81-21.05,16.3-34.96,7.85-51.38Z"/>
                        <path class="cls-2" d="M290.2,76.75c10.11,13.9.04,30.28-3.32,35.03,3.62-4.14,16.54-17.07,32.93-11.93,16.29,5.04,32.78,22.32,45.28,54.26,4.01-1.3,7-2.28,8.68-2.84,15.29-5.07,31.74-20.07,27.8-45.66-2.82-18.25-16.22-25.68-36.5-36.92-9.64-5.34-20.57-11.4-31.91-19.64-11.34-8.24-20.48-16.76-28.55-24.28-15.05-14.03-25.57-23.84-40.45-23.84-1.92,0-3.91.16-5.99.5-33.38,5.43-34.87,34.66-34.83,40.46.01,1.83.02,4.97.02,9.1,36.17,1.1,56.53,11.45,66.86,25.76Z"/>
                        <path class="cls-2" d="M109.32,99.92c19.33-6.3,33.75,13.98,33.75,13.98l.04-.06s-12.34-19.85-.53-36.4c9.81-13.87,32.51-24.16,66.74-26.19,0-4.55,0-7.93-.02-9.79-.1-16.11-9.28-36.39-34.83-40.55-2.08-.34-4.08-.5-6-.5-14.87,0-25.38,9.8-40.39,23.81-8.06,7.52-17.19,16.04-28.54,24.28-11.34,8.24-22.27,14.3-31.92,19.65-20.31,11.26-33.73,18.7-36.55,36.96-5.15,33.43,22.18,43.87,27.71,45.63,1.41.45,3.63,1.16,6.49,2.09,12.07-31.46,27.93-47.72,44.04-52.9Z"/>
                        <path class="cls-2" d="M76.91,278.25c0-18.01,17.81-26.44,21.89-28.14-4.26,1.06-23.63,4.93-34.36-9.56-10.6-14.19-13.59-39.21-3.61-74.45-2.97-.96-5.23-1.69-6.61-2.13-4.11-1.31-8.71-2.09-13.47-2.09-13,0-27.18,5.83-35.86,22.69-8.45,16.42-1.97,30.31,7.83,51.32,4.66,9.99,9.94,21.31,14.27,34.65,4.33,13.34,6.72,25.6,8.82,36.42,4.43,22.8,7.36,37.86,23.85,46.19,30.19,15.23,48.58-7.54,51.96-12.26.65-.9,1.58-2.2,2.75-3.81-26.2-21.27-37.54-41.94-37.48-58.83Z"/>
                        <path class="cls-2" d="M215.54,135.55c.82-2.95,5.53-17.94,17.38-19.87,13.56-2.2,19.46,10.09,34.57,21.08,15.11,10.98,28.61,12.77,30.7,26.35,1.74,11.27-9.75,20.07-13.09,22.37,3.73-.12,18.65.08,23.97,10.4,6.29,12.22-3.59,21.63-9.36,39.4-5.77,17.77-3.3,31.15-15.57,37.34-11.89,5.99-26.17-6.21-26.17-6.21l-.79-.62.42.96s7.19,17.36-2.18,26.81c-9.68,9.76-21.68,3.27-40.36,3.27s-30.65,6.48-40.33-3.27c-9.37-9.45-2.18-26.81-2.18-26.81l.19-.51-.19.17s-14.29,12.21-26.17,6.21c-12.27-6.19-9.81-19.61-15.58-37.37-5.77-17.77-15.64-27.14-9.35-39.37,5.81-11.29,23.08-10.47,24.67-10.37-3.12-2.13-15.01-11.04-13.25-22.48,2.1-13.58,15.61-15.39,30.73-26.37,15.11-10.98,20.98-23.26,34.55-21.06,11.94,1.94,16.64,17.17,17.4,19.94ZM215.2,171.56c-9.29.15-15.39,2.72-17.91,6.28-2.79,3.91.13,8.61.13,8.61h0s-3.41-4.78-7.98-3.29c-4.15,1.34-8.23,5.78-11.16,14.6-2.73,8.89-2.06,15.15.55,18.64,2.56,3.45,7.17,2.5,8.13,2.26-.92.38-5.18,2.36-5.18,6.65-.02,4.36,3.18,9.79,10.66,15.3,7.6,5.34,13.53,6.48,17.66,5.08,4.56-1.53,4.44-7.41,4.44-7.41h.04s-.34,6.08,4.23,7.56c4.14,1.36,9.78.37,17.33-5.05,7.43-5.59,10.85-11.25,10.79-15.61-.05-4.81-5.16-6.88-5.16-6.88v-.02s5.58,1.87,8.4-2.02c2.57-3.52,3.26-9.52.44-18.37-3.02-8.79-7.25-13.46-11.41-14.75-3.93-1.23-7,1.91-7.81,2.85.76-1.07,3.23-4.98.81-8.31-2.55-3.54-7.69-6.05-16.98-6.11Z"/>
                    </g>
                    <g>
                        <path class="cls-1" d="M576.66,110.26l-18.1-27.36c-.66-1.06,0-2.37,1.31-2.37h10.65c.66,0,1.06.41,1.31.74l11.39,16.79,11.39-16.79c.24-.33.57-.74,1.31-.74h10.65c1.31,0,1.97,1.31,1.31,2.37l-18.35,27.28v26.13c0,.82-.74,1.56-1.56,1.56h-9.75c-.9,0-1.56-.74-1.56-1.56v-26.05Z"/>
                        <path class="cls-1" d="M660.95,79.71c16.38,0,29.49,13.19,29.49,29.57s-13.11,29.41-29.49,29.41-29.41-13.03-29.41-29.41,13.03-29.57,29.41-29.57ZM660.95,125.58c9.01,0,16.38-7.37,16.38-16.3s-7.37-16.47-16.38-16.47-16.3,7.45-16.3,16.47,7.37,16.3,16.3,16.3Z"/>
                        <path class="cls-1" d="M721.64,82.08c0-.82.66-1.56,1.56-1.56h24.49c9.83,0,17.86,7.95,17.86,17.69,0,7.54-5,13.6-12.12,16.47l11.22,20.81c.57,1.07,0,2.38-1.39,2.38h-10.89c-.66,0-1.15-.41-1.31-.74l-10.89-21.71h-5.65v20.89c0,.82-.74,1.56-1.56,1.56h-9.75c-.9,0-1.56-.74-1.56-1.56v-54.23ZM746.63,105.02c3.36,0,6.23-3.11,6.23-6.55s-2.87-6.23-6.23-6.23h-12.12v12.78h12.12Z"/>
                        <path class="cls-1" d="M797.82,82.49c0-1.07.82-1.97,1.97-1.97h9.58c1.07,0,1.97.9,1.97,1.97v21.54l18.19-22.69c.33-.41,1.07-.82,1.56-.82h10.32c1.56,0,2.38,1.8,1.47,3.03l-19.17,24,20.89,27.2c.9,1.23,0,3.03-1.56,3.03h-11.3c-.57,0-1.31-.33-1.47-.57l-18.92-25.72v24.41c0,1.06-.9,1.97-1.97,1.97h-9.58c-1.15,0-1.97-.9-1.97-1.97v-53.41Z"/>
                        <path class="cls-1" d="M566.09,179.66c0-.82.74-1.56,1.56-1.56h9.75c.9,0,1.56.74,1.56,1.56v20.64h23.43v-20.64c0-.82.66-1.56,1.56-1.56h9.75c.82,0,1.56.74,1.56,1.56v54.23c0,.82-.74,1.56-1.56,1.56h-9.75c-.9,0-1.56-.74-1.56-1.56v-21.54h-23.43v21.54c0,.82-.66,1.56-1.56,1.56h-9.75c-.82,0-1.56-.74-1.56-1.56v-54.23Z"/>
                        <path class="cls-1" d="M675.85,177.29c16.38,0,29.49,13.19,29.49,29.57s-13.11,29.41-29.49,29.41-29.41-13.03-29.41-29.41,13.03-29.57,29.41-29.57ZM675.85,223.16c9.01,0,16.38-7.37,16.38-16.3s-7.37-16.47-16.38-16.47-16.3,7.45-16.3,16.47,7.37,16.3,16.3,16.3Z"/>
                        <path class="cls-1" d="M735.73,179.66c0-.82.74-1.56,1.56-1.56h10.08c.9,0,1.56.74,1.56,1.56v33.18c0,5.74,4.26,10.32,10.08,10.32s10.24-4.59,10.24-10.32v-33.18c0-.82.66-1.56,1.56-1.56h10.08c.82,0,1.56.74,1.56,1.56v33.83c0,12.45-10.49,22.77-23.43,22.77s-23.27-10.32-23.27-22.77v-33.83Z"/>
                        <path class="cls-1" d="M813.63,227.67l3.85-6.8c.66-1.06,2.21-.9,2.78-.49.33.16,6.23,4.51,11.63,4.51,3.28,0,5.65-2.05,5.65-4.91,0-3.44-2.87-6.06-8.44-8.27-7.04-2.79-15.89-8.27-15.89-18.1,0-8.11,6.31-16.3,18.92-16.3,8.52,0,15.07,4.34,17.53,6.14.98.57.82,2.05.49,2.62l-4.18,6.31c-.57.9-2.05,1.64-2.79,1.06-.74-.41-6.72-4.91-11.71-4.91-2.95,0-5.16,1.97-5.16,4.18,0,3.03,2.46,5.32,8.93,7.95,6.39,2.54,16.55,7.54,16.55,18.68,0,8.44-7.29,16.96-19.33,16.96-10.65,0-16.55-4.42-18.43-6.31-.82-.82-1.06-1.15-.41-2.29Z"/>
                        <path class="cls-1" d="M883.09,179.66c0-.82.66-1.56,1.56-1.56h33.91c.9,0,1.56.74,1.56,1.56v8.93c0,.82-.66,1.56-1.56,1.56h-22.69v10.16h18.68c.82,0,1.56.74,1.56,1.56v8.93c0,.9-.74,1.56-1.56,1.56h-18.68v11.06h22.69c.9,0,1.56.74,1.56,1.56v8.93c0,.82-.66,1.56-1.56,1.56h-33.91c-.9,0-1.56-.74-1.56-1.56v-54.23Z"/>
                        <path class="cls-1" d="M562.81,325.25l3.85-6.8c.66-1.06,2.21-.9,2.78-.49.33.16,6.23,4.51,11.63,4.51,3.28,0,5.65-2.05,5.65-4.91,0-3.44-2.87-6.06-8.44-8.27-7.04-2.79-15.89-8.27-15.89-18.1,0-8.11,6.31-16.3,18.92-16.3,8.52,0,15.07,4.34,17.53,6.14.98.57.82,2.05.49,2.62l-4.18,6.31c-.57.9-2.05,1.64-2.79,1.06-.74-.41-6.72-4.91-11.71-4.91-2.95,0-5.16,1.97-5.16,4.18,0,3.03,2.46,5.32,8.93,7.95,6.39,2.54,16.55,7.54,16.55,18.68,0,8.44-7.29,16.96-19.33,16.96-10.65,0-16.55-4.42-18.43-6.31-.82-.82-1.06-1.15-.41-2.29Z"/>
                        <path class="cls-1" d="M657.67,274.87c8.19,0,14.25,2.54,19.82,7.62.74.66.74,1.64.08,2.29l-6.39,6.64c-.57.57-1.47.57-2.05,0-3.03-2.7-7.04-4.18-11.06-4.18-9.26,0-16.06,7.7-16.06,16.88s6.88,16.63,16.14,16.63c3.85,0,8.03-1.39,10.98-3.93.57-.49,1.64-.49,2.13.08l6.39,6.8c.57.57.49,1.64-.08,2.21-5.57,5.41-12.62,7.95-19.91,7.95-16.38,0-29.57-13.03-29.57-29.41s13.19-29.57,29.57-29.57Z"/>
                        <path class="cls-1" d="M708.7,277.25c0-.82.74-1.56,1.56-1.56h9.75c.9,0,1.56.74,1.56,1.56v20.64h23.43v-20.64c0-.82.66-1.56,1.56-1.56h9.75c.82,0,1.56.74,1.56,1.56v54.23c0,.82-.74,1.56-1.56,1.56h-9.75c-.9,0-1.56-.74-1.56-1.56v-21.54h-23.43v21.54c0,.82-.66,1.56-1.56,1.56h-9.75c-.82,0-1.56-.74-1.56-1.56v-54.23Z"/>
                        <path class="cls-1" d="M818.46,274.87c16.38,0,29.49,13.19,29.49,29.57s-13.11,29.41-29.49,29.41-29.41-13.03-29.41-29.41,13.03-29.57,29.41-29.57ZM818.46,320.75c9.01,0,16.38-7.37,16.38-16.3s-7.37-16.47-16.38-16.47-16.3,7.45-16.3,16.47,7.37,16.3,16.3,16.3Z"/>
                        <path class="cls-1" d="M904.39,274.87c16.38,0,29.49,13.19,29.49,29.57s-13.11,29.41-29.49,29.41-29.41-13.03-29.41-29.41,13.03-29.57,29.41-29.57ZM904.39,320.75c9.01,0,16.38-7.37,16.38-16.3s-7.37-16.47-16.38-16.47-16.3,7.45-16.3,16.47,7.37,16.3,16.3,16.3Z"/>
                        <path class="cls-1" d="M965.09,277.25c0-.82.66-1.56,1.56-1.56h9.75c.82,0,1.56.74,1.56,1.56v43.75h19.5c.9,0,1.56.74,1.56,1.56v8.93c0,.82-.66,1.56-1.56,1.56h-30.8c-.9,0-1.56-.74-1.56-1.56v-54.23Z"/>
                    </g>
                </svg>
            </a>
            <nav>
                <a href="https://www.facebook.com/yorkhouseschool/" target="_blank" class="external-media-icon">
                    <svg width="37" height="36" viewBox="0 0 25 24" fill="white" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M20 1C21.6569 1 23 2.34315 23 4V20C23 21.6569 21.6569 23 20 23H4C2.34315 23 1 21.6569 1 20V4C1 2.34315 2.34315 1 4 1H20ZM20 3C20.5523 3 21 3.44772 21 4V20C21 20.5523 20.5523 21 20 21H15V13.9999H17.0762C17.5066 13.9999 17.8887 13.7245 18.0249 13.3161L18.4679 11.9871C18.6298 11.5014 18.2683 10.9999 17.7564 10.9999H15V8.99992C15 8.49992 15.5 7.99992 16 7.99992H18C18.5523 7.99992 19 7.5522 19 6.99992V6.31393C19 5.99091 18.7937 5.7013 18.4813 5.61887C17.1705 5.27295 16 5.27295 16 5.27295C13.5 5.27295 12 6.99992 12 8.49992V10.9999H10C9.44772 10.9999 9 11.4476 9 11.9999V12.9999C9 13.5522 9.44771 13.9999 10 13.9999H12V21H4C3.44772 21 3 20.5523 3 20V4C3 3.44772 3.44772 3 4 3H20Z" />
                    </svg>
                </a>
                <a href="https://www.instagram.com/yorkhousevan/" target="_blank" class="external-media-icon">
                    <svg width="37" height="36" viewBox="0 0 25 24" fill="white" xmlns="http://www.w3.org/2000/svg">
                        <path d="M12.98 2.163C16.184 2.163 16.564 2.175 17.83 2.233C21.082 2.381 22.601 3.924 22.749 7.152C22.807 8.417 22.818 8.797 22.818 12.001C22.818 15.206 22.806 15.585 22.749 16.85C22.6 20.075 21.085 21.621 17.83 21.769C16.564 21.827 16.186 21.839 12.98 21.839C9.77604 21.839 9.39604 21.827 8.13104 21.769C4.87104 21.62 3.36004 20.07 3.21204 16.849C3.15404 15.584 3.14204 15.205 3.14204 12C3.14204 8.796 3.15504 8.417 3.21204 7.151C3.36104 3.924 4.87604 2.38 8.13104 2.232C9.39704 2.175 9.77604 2.163 12.98 2.163ZM12.98 0C9.72104 0 9.31304 0.014 8.03304 0.072C3.67504 0.272 1.25304 2.69 1.05304 7.052C0.994042 8.333 0.980042 8.741 0.980042 12C0.980042 15.259 0.994042 15.668 1.05204 16.948C1.25204 21.306 3.67004 23.728 8.03204 23.928C9.31304 23.986 9.72104 24 12.98 24C16.239 24 16.648 23.986 17.928 23.928C22.282 23.728 24.71 21.31 24.907 16.948C24.966 15.668 24.98 15.259 24.98 12C24.98 8.741 24.966 8.333 24.908 7.053C24.712 2.699 22.291 0.273 17.929 0.073C16.648 0.014 16.239 0 12.98 0ZM12.98 5.838C9.57704 5.838 6.81804 8.597 6.81804 12C6.81804 15.403 9.57704 18.163 12.98 18.163C16.383 18.163 19.142 15.404 19.142 12C19.142 8.597 16.383 5.838 12.98 5.838ZM12.98 16C10.771 16 8.98004 14.21 8.98004 12C8.98004 9.791 10.771 8 12.98 8C15.189 8 16.98 9.791 16.98 12C16.98 14.21 15.189 16 12.98 16ZM19.386 4.155C18.59 4.155 17.945 4.8 17.945 5.595C17.945 6.39 18.59 7.035 19.386 7.035C20.181 7.035 20.825 6.39 20.825 5.595C20.825 4.8 20.181 4.155 19.386 4.155Z" />
                    </svg>
                </a>
                <a href="https://www.linkedin.com/company/york-house-school" target="_blank" class="external-media-icon">
                    <svg width="37" height="36" viewBox="0 0 25 24" fill="white" xmlns="http://www.w3.org/2000/svg">
                        <path d="M19.98 0H5.98004C3.21904 0 0.980042 2.239 0.980042 5V19C0.980042 21.761 3.21904 24 5.98004 24H19.98C22.742 24 24.98 21.761 24.98 19V5C24.98 2.239 22.742 0 19.98 0ZM8.98004 19H5.98004V8H8.98004V19ZM7.48004 6.732C6.51404 6.732 5.73004 5.942 5.73004 4.968C5.73004 3.994 6.51404 3.204 7.48004 3.204C8.44604 3.204 9.23004 3.994 9.23004 4.968C9.23004 5.942 8.44704 6.732 7.48004 6.732ZM20.98 19H17.98V13.396C17.98 10.028 13.98 10.283 13.98 13.396V19H10.98V8H13.98V9.765C15.376 7.179 20.98 6.988 20.98 12.241V19Z" />
                    </svg>
                </a>
                <a href="https://www.youtube.com/yorkhousedotca" target="_blank" class="external-media-icon">
                    <svg width="37" height="36" viewBox="0 0 25 18" fill="white" xmlns="http://www.w3.org/2000/svg">
                        <path d="M20.595 0.184003C16.991 -0.0619969 8.96404 -0.0609969 5.36504 0.184003C1.46804 0.450003 1.00904 2.804 0.980042 9C1.00904 15.185 1.46404 17.549 5.36504 17.816C8.96504 18.061 16.991 18.062 20.595 17.816C24.492 17.55 24.951 15.196 24.98 9C24.951 2.815 24.496 0.451003 20.595 0.184003ZM9.98004 13V5L17.98 8.993L9.98004 13Z" />
                    </svg>
                </a>
            </nav>
        </div>
        <form id="help-form" action="https://docs.google.com/forms/u/0/d/e/1FAIpQLSdPOEaLxfht1ap8IFeZdl_YmqDv2H2p9whpmCyyCQBBoDenJw/formResponse?embedded=true" target="dummyframe" method="POST">
            <!--Using: https://dev.to/ninest/natively-embed-google-forms-in-your-website-57g3-->
            <h2>Have a Question?</h2>
            <input type="email" name="emailAddress" placeholder="YourEmail@yorkhouse.ca" required>
            <div>
                <textarea name="entry.2135211842"
                            placeholder="What database should I use for biographies?&#10;How do I request the library to order a new book?&#10;What is the tallest building in the world?" required></textarea>
                <button type="submit"></button>
            </div>
            <iframe name="dummyframe" id="dummyframe" style="display: none;"></iframe>
        </form>
    </div>
    <nav class="site-nav">
        <dl class="nav-item">
            <dt>Resources</dt>
            <dd><a target="_blank" href="/az.php">All Resources</a></dd>
            <dd><a target="_blank" href="/resources/catalogue">Our Catalogue</a></dd>
            <dd><a target="_blank" href="/resources/sora">Sora E-Books</a></dd>
            <dd><a target="_blank" href="/orders">Request A Title</a></dd>
            <dd><a target="_blank" href="/az.php?s=138977">Databases - Multi-Subject</a></dd>
            <dd><a target="_blank" href="/az.php?s=138907">Databases - English</a></dd>
            <dd><a target="_blank" href="/az.php?s=138908">Databases - Science</a></dd>
            <dd><a target="_blank" href="/az.php?s=138909">Databases - Socials</a></dd>
            <dd><a target="_blank" href="/az.php?t=28808">News Sources</a></dd>
        </dl>
        <dl class="nav-item">
            <dt>How To</dt>
            <dd><a target="_blank" href="/how-to">All "How To" Guides</a></dd>
            <dd><a target="_blank" href="/how-to/assess-reliability">Assess Reliability</a></dd>
            <dd><a target="_blank" href="/how-to/research-sources">Searching for Sources</a></dd>
            <dd><a target="_blank" href="/how-to/find-your-book">Find Your Next Book</a></dd>
            <dd><a target="_blank" href="/how-to/3d-printing">3D Printing</a></dd>
        </dl>
        <dl class="nav-item">
            <dt>Collections</dt>
            <dd><a target="_blank" href="/collections">All Collections</a></dd>
            <dd><a target="_blank" href="/collections/reading-lists">Reading Lists</a></dd>
            <dd><a target="_blank" href="/collections/publications">Student Publications</a></dd>
            <dd><a target="_blank" href="/collections/anti-islamophobia">Anti Islamophobia</a></dd>
            <dd><a target="_blank" href="/collections/asian-heritage">Asian Heritage</a></dd>
            <dd><a target="_blank" href="/collections/black-history">Black History</a></dd>
            <dd><a target="_blank" href="/collections/first-nations">First Nations</a></dd>
            <dd><a target="_blank" href="/collections/mental-health">Mental Health</a></dd>
            <dd><a target="_blank" href="/collections/neurodiversity">Neurodiveristy</a></dd>
        </dl>
        <dl class="nav-item">
            <dt>Collaboration</dt>
            <dd><a target="_blank" href="/collaboration">All Collaboration</a></dd>
            <dd><a target="_blank" href="/collaboration/2025-26">2025-26 (Current)</a></dd>
            <dd><a target="_blank" href="/collaboration/2025-25">2024-25</a></dd>
            <dd><a target="_blank" href="/collaboration/2023-24">2023-24</a></dd>
        </dl>
        <dl class="nav-item">
            <dt>Student Initiatives</dt>
            <dd><a target="_blank" href="/initiatives">All Initiatives</a></dd>
            <dd><a target="_blank" href="/initiatives/publications">Student Publications</a></dd>
            <dd><a target="_blank" href="/initiatives/model-un">Model UN</a></dd>
        </dl>
        <dl class="nav-item">
            <dt>Miscellaneous</dt>
            <dd><a target="_blank" href="/about">About Us</a></dd>
            <dd><a id="admin-login-link" target="_blank"
                    href="https://yorkhouse.libapps.com/libapps/login.php?site_id=26075&target64=L2xpYmd1aWRlcy9hZG1pbl9jLnBocD9nPTc0MzcxMyZwPTUzNzcxMjA=">Admin
                    Login</a></dd>
        </dl>
    </nav>
    <span id="default-disclaimer">Powered by Springshare. All rights reserved.</span>
</div>

    <div id="default-footer" style="display: none;"> <div id="s-lib-footer-public" class="container s-lib-footer footer s-lib-side-borders">
    <div>
        <div id="s-lib-footer-brand">
            Powered by Springshare.
        </div>
        <div id="s-lib-footer-rights">
            All rights reserved.
        </div>
        <div id="s-lib-footer-login-link">
            <a href="https://yorkhouse.libapps.com/libapps/login.php?site_id=26075">Login to LibApps</a>
        </div>
    </div>
    <div>
        <div id="s-lib-footer-support-link">
            <a href="https://docs.google.com/forms/d/e/1FAIpQLSdPOEaLxfht1ap8IFeZdl_YmqDv2H2p9whpmCyyCQBBoDenJw/viewform">Report a problem.</a>
        </div>
    </div>
</div> </div>
    <div id="default-libguide-utilities">
        <div id="s-lib-alert" title="">
            <div id="s-lib-alert-content"></div>
        </div>
        <!-- popover.twig -->
        <div id="s-lib-popover-title" class="hide">
            <span class="text-info">
                <strong>title</strong>
            </span>

            <button type="button" id="popclose" class="close" onclick="jQuery('.s-lib-popover').popover('hide')">
                &times;
            </button>
        </div>
        <div id="s-lib-popover-content" class="hide">
            <i class="fa fa-refresh fa-spin"></i> Loading...
            <button class="btn btn-default btn-sm popclose" type="button">Close</button>
        </div>
        <!-- !popover.twig -->
    </div>
</body>
</html>
